import Script from 'next/script';
import './globals.css';
export const metadata={title:'G.R.D. Motors eBill',description:'Modern eBill administration',appleWebApp:{capable:true,title:'GRD eBill',statusBarStyle:'default'}};
export const viewport={width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#356311'};

// Sets data-theme on <html> before React hydrates/paints, so a saved "dark"
// preference doesn't flash light-mode for a frame on reload.
// Initialize one of the eight preset themes before React paints.
const THEME_INIT = `(function(){try{var allowed=['green-olive','lavender-soft','white-black','navy-gold','maroon-cream','teal-charcoal','purple-lavender','red-classic'];var t=localStorage.getItem('ebill_theme');if(t==='grey-white')t='lavender-soft';if(t==='coral-sand')t='red-classic';if(allowed.indexOf(t)<0)t='green-olive';document.documentElement.setAttribute('data-theme',t);}catch(e){}})();`;

export default function RootLayout({children}){
  return (
    <html lang="en" suppressHydrationWarning>
      <head><Script id="theme-init" strategy="beforeInteractive">{THEME_INIT}</Script></head>
      <body>{children}</body>
    </html>
  );
}
