'use client';
import { useEffect, useState } from 'react';
import { get, post, put, del, getToken } from '../lib/api';
import { STATE_NAMES, stateCodeFor } from '../lib/states';
import { Field, ErrorBanner, EmptyState, useAsyncAction } from './ui';

// Re-encodes the chosen image as a JPEG in the browser before upload, so the
// bytes saved on the server always match the .jpg extension that the
// Delivery Challan / Invoice print views look for (see PrintDocs.jsx).
function toJpeg(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      canvas.toBlob((blob) => {
        URL.revokeObjectURL(url);
        if (blob) resolve(blob); else reject(new Error('Image could not be processed.'));
      }, 'image/jpeg', 0.92);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not a valid image.')); };
    img.src = url;
  });
}

// Uploads a finished-good logo, stored in the database (Vercel's file system is read-only).
function LogoUploadField({ umrnCode }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [ok, setOk] = useState(false);
  const [version, setVersion] = useState(0);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const code = (umrnCode || '').trim();
    if (!code) {
      setOk(false);
      setMsg('Pehle UMRN Code bharo, uske baad hi logo upload hoga.');
      return;
    }
    setBusy(true);
    setMsg('');
    try {
      const jpeg = await toJpeg(file);
      const fd = new FormData();
      fd.append('umrn_code', code);
      fd.append('file', jpeg, `${code}.jpg`);
      const token = getToken();
      const r = await fetch('/api/logo-upload', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: fd,
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || 'Upload failed.');
      setOk(true);
      setMsg('Logo upload ho gaya ✓');
      setVersion((v) => v + 1);
    } catch (err) {
      setOk(false);
      setMsg(err.message || 'Upload failed.');
    } finally {
      setBusy(false);
    }
  };

  const code = (umrnCode || '').trim();

  return (
    <div className="field">
      <label>Finished Good Logo</label>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {code && (
          <img
            key={version}
            src={`/api/umrn-logo/${encodeURIComponent(code)}?v=${version}`}
            alt=""
            style={{ width: 40, height: 40, objectFit: 'contain', border: '1px solid #e4e7ec', borderRadius: 6, background: '#fff' }}
            onError={(e) => {
              const el = e.currentTarget;
              if (!el.dataset.fb) { el.dataset.fb = '1'; el.src = `/UMRN/${code}.jpg`; } else el.style.visibility = 'hidden';
            }}
          />
        )}
        <input type="file" accept="image/*" onChange={handleFile} disabled={busy} />
      </div>
      {busy && <div style={{ fontSize: 12, color: '#667085', marginTop: 4 }}>Uploading…</div>}
      {msg && <div style={{ fontSize: 12, color: ok ? '#12b76a' : '#d92d2d', marginTop: 4 }}>{msg}</div>}
      <div style={{ fontSize: 11, color: '#98a2b3', marginTop: 4 }}>
        Saved in the database for UMRN Code {code || '<UMRN Code>'} — Delivery Challan &amp; Invoice prints pick it up automatically.
      </div>
    </div>
  );
}

const modsOf = (d) => (Array.isArray(d?.portal_modules) ? d.portal_modules : String(d?.portal_modules || '').split(',')).map((x) => String(x).replace(/[{}"\[\]]/g, '').trim()).filter(Boolean);

export function DealerPage() {
  const [dealers, setDealers] = useState([]);
  const [salesmen, setSalesmen] = useState([]);
  const [search, setSearch] = useState('');
  const [suggestedCode, setSuggestedCode] = useState('');
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({});
  const { busy, error, setError, run } = useAsyncAction();

  const load = () => Promise.all([get('/dealers'), get('/masters/salesman').catch(() => [])]).then(([d, sm]) => {
    setDealers(d.dealers || []);
    setSalesmen(Array.isArray(sm) ? sm : (sm?.masters || sm?.rows || sm?.data || sm?.items || []));
    setSuggestedCode(d.suggested_code);
  })
    .catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const filteredDealers = dealers.filter((d) => {
 const q = search.trim().toLowerCase();
 if (!q) return true;
 const hay = [d.code, d.name, d.mobile, d.gst_no, d.login_id, d.salesman, d.state, d.category].join(' ').toLowerCase();
 return q.split(/\s+/).filter(Boolean).every((t) => hay.includes(t));
 });

 const openNew = () => { setEditingId(null); setForm({ code: suggestedCode, state_code: '07', registration_type: 'registered', sub_group_name: 'Primary' }); setOpen(true); };
  const openEdit = (d) => { setEditingId(d.id); const { password, password_hash, ...rest } = d; setForm({ ...rest }); setOpen(true); };

  const save = (e) => {
    e.preventDefault();
    run(async () => { const body = { ...form, id: editingId || undefined }; if (!String(body.password || '').trim()) delete body.password; await post('/dealers', body); setOpen(false); setEditingId(null); load(); });
  };

  const remove = (id) => {
    if (!confirm('Delete this dealer? This cannot be undone.')) return;
    run(async () => { await del(`/dealers/${id}`); setOpen(false); setEditingId(null); load(); });
  };

  return (
    <>
      <div className="actions" style={{ marginBottom: 14 }}>
        <div className="actions"><input className="input" placeholder="Search dealer name, code, mobile, salesman…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ maxWidth: 320 }} />{search && <button className="btn" onClick={() => setSearch('')}>Clear</button>}<button className="btn primary" onClick={openNew}>+ Add Dealer</button></div>
      </div>
      <ErrorBanner message={!open ? error : ''} />
      {dealers.length === 0 ? <EmptyState /> : filteredDealers.length === 0 ? <EmptyState text="No dealers match your search." /> : (
        <div className="tablewrap">
          <table className="table">
            <thead><tr><th>Code</th><th>Name</th><th>Mobile</th><th>GSTIN</th><th>Category</th><th>Type</th><th>State</th><th>Salesman</th><th>Login ID</th><th>Blocked</th></tr></thead>
            <tbody>
              {filteredDealers.map((d) => (
                <tr key={d.id}>
                  <td>{d.code}</td>
                  <td>
                    <a onClick={() => openEdit(d)} style={{ color: 'var(--accent)', cursor: 'pointer' }}>
                      {d.name}
                    </a>
                  </td>
                  <td>{d.mobile}</td><td>{d.gst_no}</td><td>{d.dealer_category === 'showroom' ? 'Showroom / Branch' : 'Dealer'}</td><td>{d.registration_type === "unregistered" ? "Unregistered" : "Registered"}</td>
                  <td>{d.state} {d.state_code ? `(${d.state_code})` : ''}</td>
                  <td>{d.salesman || ''}</td>
                  <td>{d.login_id}</td><td>{d.blocked ? 'Yes' : 'No'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {open && (
        <div className="modal">
          <form className="modalbox dealerFormWide" onSubmit={save}>
            <h2>{editingId ? 'Edit Dealer' : 'Add Dealer'}</h2>
            <ErrorBanner message={error} />
            <div className="dealerSplit">
            <div className="formgrid">
              <Field label="Dealer Code" value={form.code} onChange={(v) => setForm({ ...form, code: v })} />
              <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
              <Field label="Address Line 1" value={form.address1} onChange={(v) => setForm({ ...form, address1: v })} />
              <Field label="Address Line 2" value={form.address2} onChange={(v) => setForm({ ...form, address2: v })} />
              <Field label="Pin Code" value={form.pincode} onChange={(v) => setForm({ ...form, pincode: String(v || '').replace(/\D/g, '').slice(0, 6) })} />
              <Field label="Mobile" value={form.mobile} onChange={(v) => setForm({ ...form, mobile: v })} />
              <Field label="GSTIN" value={form.gst_no} onChange={(v) => setForm({ ...form, gst_no: v })} />
              <Field label="Dealer Category" type="select" value={form.dealer_category || "dealer"} onChange={(v) => setForm({ ...form, dealer_category: v })} options={[{value:"showroom",label:"Showroom / Branch"},{value:"dealer",label:"Dealer"}]} />
              {form.dealer_category !== 'showroom' && <Field label="Dealer Registration" type="select" value={form.registration_type || "registered"} onChange={(v) => setForm({ ...form, registration_type: v, purchase_access: v === 'unregistered' ? false : form.purchase_access })} options={[{value:"registered",label:"Registered Dealer"},{value:"unregistered",label:"Unregistered Dealer"}]} />}
              <Field label="State" type="combo" value={form.state} options={STATE_NAMES} onChange={(v) => { const c = stateCodeFor(v); setForm({ ...form, state: v, ...(c ? { state_code: c } : {}) }); }} />
              <Field label="State Code" value={form.state_code} onChange={(v) => setForm({ ...form, state_code: v })} />
              <Field label="PAN" value={form.pan} onChange={(v) => setForm({ ...form, pan: v })} />
              <Field label="Bank Name" value={form.bank_name} onChange={(v) => setForm({ ...form, bank_name: v })} />
              <Field label="Bank Account No." value={form.bank_account_no} onChange={(v) => setForm({ ...form, bank_account_no: v })} />
              <Field label="Bank IFSC" value={form.bank_ifsc} onChange={(v) => setForm({ ...form, bank_ifsc: v })} />
              <Field label="Salesman" type="select" value={form.salesman || ''} onChange={(v) => setForm({ ...form, salesman: v })} options={[{ value: '', label: 'Select Salesman' }, ...salesmen.map((u) => { const n = u.name || u.value || u.label || ''; return { value: n, label: n }; }).filter((o) => o.value)]} />
            </div>
            <div className="dealerSplitRight">
            <div className="formgrid">
              <Field label="Blocked" type="checkbox" value={form.blocked} onChange={(v) => setForm({ ...form, blocked: v })} />
              <Field label="Allow Purchase / Customer Invoice" type="checkbox" value={form.purchase_access && form.registration_type !== 'unregistered'} disabled={form.registration_type === 'unregistered'} onChange={(v) => setForm({ ...form, purchase_access: form.registration_type === 'unregistered' ? false : v })} />
              <div className="field" style={{gridColumn:'1/-1'}}>
                <label>Dealer Portal Permissions</label>
                <div className="dealerPerms">
                  {[
                    ['battery-withdrawal','Battery Withdrawal'],
                    ['battery-swap','Battery Swap / Exchange'],
                    ['battery-addition','Battery Fit to Rickshaw'],
                    ['purchase-portal','Purchases / Customer Invoice'],
                    ['cashbook','Cash Book'],
                    ['loan-status','Loan Status'],
                    ['old-rickshaw-sales','Old Rickshaw Sale'],
                    ['repair-receipt','Repair Payment Receipt'],
                  ].map(([key,label])=>{
                    return <label key={key}>
                      <input type="checkbox" checked={modsOf(form).includes(key)} onChange={e=>{
                        const a=new Set(modsOf(form)); e.target.checked?a.add(key):a.delete(key); setForm({...form,portal_modules:[...a]});
                      }}/> {label}
                    </label>;
                  })}
                </div>
              </div>
              <Field label="Dealer Login ID" name="dealer_login_id" autoComplete="off" value={form.login_id} onChange={(v) => setForm({ ...form, login_id: v })} />
              <Field label="Dealer Password" name="dealer_new_password" type="password" autoComplete="new-password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
            </div>
            <div className="actions" style={{ marginTop: 18, justifyContent: 'space-between' }}>
              {editingId ? (
                <div style={{ display: 'flex', gap: 8 }}>
                  <button type="button" className="btn danger" disabled={busy} onClick={() => remove(editingId)}>Delete</button>
                  <button type="button" className="btn" disabled={busy} onClick={() => {
                    if (!window.confirm('Is dealer ka login PIN reset karein? Dealer ko next login par naya PIN set karna hoga.')) return;
                    run(async () => { await post(`/dealers/${editingId}/reset-pin`, {}); window.alert('PIN reset ho gaya. Dealer next login par naya PIN set karega.'); });
                  }}>Reset PIN</button>
                </div>
              ) : <span />}
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="btn" onClick={() => { setOpen(false); setEditingId(null); }}>Cancel</button>
                <button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
              </div>
            </div>
            </div>
            </div>
          </form>
        </div>
      )}
    </>
  );
}

// Small table-cell indicator: shows whether a finished product's UMRN logo
// file actually exists on disk (tries loading it and reacts to onError),
// with a tiny inline preview thumbnail when it does.
function LogoStatusCell({ umrnCode, fro }) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (fro !== 'F') return <span className="muted">—</span>;
  const code = (umrnCode || '').trim();
  if (!code) return <span className="pill d">No UMRN</span>;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      {!failed && (
        <img
          src={`/api/umrn-logo/${encodeURIComponent(code)}`}
          alt=""
          onLoad={() => setLoaded(true)}
          onError={(e) => {
            const el = e.currentTarget;
            if (!el.dataset.fb) { el.dataset.fb = '1'; el.src = `/UMRN/${code}.jpg`; } else setFailed(true);
          }}
          style={{ width: 26, height: 26, objectFit: 'contain', border: '1px solid #e4e7ec', borderRadius: 5, background: '#fff', display: loaded ? 'block' : 'none' }}
        />
      )}
      {failed ? (
        <span className="pill d">No Logo</span>
      ) : loaded ? (
        <span className="pill t">Uploaded</span>
      ) : (
        <span className="muted">Checking…</span>
      )}
    </div>
  );
}

export function ProductPage() {
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [page, setPage] = useState(1);
  const [meta, setMeta] = useState(null);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({ unit: 'PCS', fro: 'F', fuel_type: 'Battery/Electric', gst_rate: 5, sub_group_name: 'Primary' });
  const [subGroups, setSubGroups] = useState([{name:'Primary'}]);
  const [newSubGroup, setNewSubGroup] = useState('');
  const { busy, error, setError, run } = useAsyncAction();

  const load = (p = page) => {
    const params = new URLSearchParams({ page: p, per_page: 50 });
    if (typeFilter === 'F') params.set('category', 'FINISHED');
    else if (typeFilter === 'R') params.set('category', 'RAW');
    else if (typeFilter === 'D') params.set('category', 'DISPATCH');
    if (search.trim()) params.set('search', search.trim());
    get(`/products?${params}`).then((d) => { setRows(d.products || []); setMeta(d); }).catch((e) => setError(e.message));
  };
  useEffect(() => {
    get('/sub-groups').then((d) => setSubGroups(d.sub_groups || d.rows || [{ name: 'Primary' }])).catch(() => {});
  }, []);
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(1); }, 250);
    return () => clearTimeout(t);
  }, [typeFilter, search]);

  const goPage = (p) => { setPage(p); load(p); };

  const filtered = rows;

  const openNew = () => {
    setEditingId(null);
    setForm({ unit: 'PCS', fro: 'F', product_category: 'FINISHED', show_on_delivery_challan: false, fuel_type: 'Battery/Electric', gst_rate: 5, sub_group_name: 'Primary' });
    setOpen(true);
  };

  const openEdit = (p) => {
    setEditingId(p.id);
    setForm({ ...p });
    setOpen(true);
  };

  const save = (e) => {
    e.preventDefault();
    run(async () => {
      // Duplicate check: same naam / same code wala product pehle se ho to save nahi hoga.
      const norm = (v) => String(v || '').trim().toLowerCase().replace(/\s+/g, ' ');
      const nm = norm(form.name), cd = norm(form.code);
      const found = [];
      for (const q of [form.name, form.code]) {
        if (!String(q || '').trim()) continue;
        const r = await get(`/products?${new URLSearchParams({ page: 1, per_page: 100, search: String(q).trim() })}`);
        found.push(...(r.products || []));
      }
      const same = found.find((x) => String(x.id) !== String(editingId || '') &&
        ((nm && norm(x.name) === nm) || (cd && norm(x.code) === cd)));
      if (same) {
        throw new Error(norm(same.name) === nm
          ? `"${same.name}" naam ka product pehle se bana hua hai (Code: ${same.code || '-'}). Duplicate nahi ban sakta.`
          : `Code "${same.code}" pehle se "${same.name}" product me use ho raha hai.`);
      }
      // Screen par Full Chassis No. Length 17 dikhta hai (default), par form me save nahi hota tha -> DB me blank reh jata tha.
      // Finished product ke liye wo dikhne wali value ab hamesha save hoti hai.
      const payload = { ...form };
      // Khali Purchase Price DB me '' (numeric error) ki jagah NULL jaye.
      payload.purchase_price = String(payload.purchase_price ?? '').trim() === '' ? null : Number(payload.purchase_price);
      if (String(payload.fro || 'F') === 'F' && (payload.chassis_length_digits === undefined || payload.chassis_length_digits === null || payload.chassis_length_digits === '')) {
        payload.chassis_length_digits = 17;
      }
      if (editingId) {
        await put(`/products/${editingId}`, { ...payload, id: undefined });
      } else {
        await post('/products', payload);
      }
      setOpen(false);
      setEditingId(null);
      load(1);
    });
  };

  const remove = (id) => {
    if (!confirm('Delete this product?')) return;
    run(async () => { await del(`/products/${id}`); setOpen(false); setEditingId(null); load(page); });
  };

  return (
    <>
      <div className="actions" style={{ marginBottom: 14 }}>
        <button className="btn primary" onClick={openNew}>+ Add Product</button>
        <button className={'btn' + (typeFilter === 'ALL' ? ' primary' : '')} onClick={() => setTypeFilter('ALL')}>All</button>
        <button className={'btn' + (typeFilter === 'F' ? ' primary' : '')} onClick={() => setTypeFilter('F')}>Finished</button>
        <button className={'btn' + (typeFilter === 'R' ? ' primary' : '')} onClick={() => setTypeFilter('R')}>Raw Material</button>
        <button className={'btn' + (typeFilter === 'D' ? ' primary' : '')} onClick={() => setTypeFilter('D')}>Dispatch</button>
        <input className="input" placeholder="Search by name, code, HSN or chassis item code"
               value={search} onChange={(e) => setSearch(e.target.value)} style={{ maxWidth: 340 }} />
        {search && <button className="btn" onClick={() => setSearch('')}>Clear</button>}
      </div>
      <ErrorBanner message={!open ? error : ''} />
      {filtered.length === 0 ? <EmptyState text={search ? 'No products match your search.' : undefined} /> : (
        <div className="tablewrap">
          <table className="table">
            <thead><tr><th>Code</th><th>Name</th><th>Sub Group</th><th>Type</th><th>Unit</th><th>GST %</th><th>HSN</th><th>Purchase Price</th><th>Chassis Item Code</th><th>Logo</th></tr></thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id}>
                  <td>{p.code}</td>
                  <td>
                    <a onClick={() => openEdit(p)} style={{ color: 'var(--accent)', cursor: 'pointer' }}>
                      {p.name}
                    </a>
                  </td>
                  <td>{p.sub_group_name || 'Primary'}</td>
                  <td>{String(p.category || p.product_category || '').toUpperCase() === 'DISPATCH' ? 'Dispatch' : String(p.category || p.product_category || '').toUpperCase() === 'FINISHED' ? 'Finished' : 'Raw Material'}</td>
                  <td>{p.unit}</td><td>{p.gst_rate}</td><td>{p.hsn_code}</td><td>{Number(p.purchase_price) > 0 ? Number(p.purchase_price).toLocaleString('en-IN') : '—'}</td><td>{p.chassis_item_code}</td>
                  <td><LogoStatusCell umrnCode={p.umrn_code} fro={p.fro} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {meta && (meta.total_pages || 1) > 1 && (
        <div className="actions" style={{ marginTop: 12, alignItems: 'center' }}>
          <button className="btn" disabled={page <= 1} onClick={() => goPage(page - 1)}>← Prev</button>
          <span className="muted">Page {page} of {meta.total_pages} ({meta.total} products)</span>
          <button className="btn" disabled={page >= meta.total_pages} onClick={() => goPage(page + 1)}>Next →</button>
        </div>
      )}
      {open && (
        <div className="modal">
          <form className="modalbox" onSubmit={save}>
            <h2>{editingId ? 'Edit Product' : 'Add Product'}</h2>
            <ErrorBanner message={error} />
            <div className="formgrid">
              <Field label="Code" value={form.code} onChange={(v) => setForm({ ...form, code: v })} />
              <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
              <Field label="Category" type="select" value={form.product_category || (form.fro === 'F' ? 'FINISHED' : 'RAW')}
                     options={[{ value: 'RAW', label: 'Raw' }, { value: 'FINISHED', label: 'Finished' }, { value: 'DISPATCH', label: 'Dispatch' }]}
                     onChange={(v) => setForm({ ...form, product_category: v, show_on_delivery_challan: v === 'DISPATCH' ? !!form.show_on_delivery_challan : false })} />
              {String(form.product_category || '').toUpperCase() === 'DISPATCH' && (
                <Field label="Show on Delivery Challan?" type="select" value={form.show_on_delivery_challan ? 'YES' : 'NO'}
                       options={[{ value: 'YES', label: 'Yes' }, { value: 'NO', label: 'No' }]}
                       onChange={(v) => setForm({ ...form, show_on_delivery_challan: v === 'YES' })} />
              )}
              <Field label="Unit" value={form.unit} onChange={(v) => setForm({ ...form, unit: v })} />
              <Field label="GST Rate %" type="number" value={form.gst_rate} onChange={(v) => setForm({ ...form, gst_rate: v })} />
              <Field label="HSN Code" value={form.hsn_code} onChange={(v) => setForm({ ...form, hsn_code: v })} />
              <Field label="Purchase Price / Cost Rate (₹, GST ke bina)" type="number" min="0" step="0.01" value={form.purchase_price ?? ''} onChange={(v) => setForm({ ...form, purchase_price: v })} />
              {form.fro === 'F' && (
                <>
                  <Field label="Chassis First Fix" value={form.chassis_first_fix ?? form.chassis_item_code ?? ''}
                         onChange={(v) => setForm({ ...form, chassis_first_fix: v, chassis_item_code: v })} />
                  <Field label="After Month & Year Fix" value={form.chassis_after_month_year_fix ?? ''}
                         onChange={(v) => setForm({ ...form, chassis_after_month_year_fix: v })} />
                  <Field label="Full Chassis No. Length" type="number" min="1" max="30" value={form.chassis_length_digits ?? 17}
                         onChange={(v) => setForm({ ...form, chassis_length_digits: v })} />
                </>
              )}
              <Field label="Type Approval No. (Form-22)" value={form.type_approval_no} onChange={(v) => setForm({ ...form, type_approval_no: v })} />
              <Field label="Fuel Type" value={form.fuel_type} onChange={(v) => setForm({ ...form, fuel_type: v })} />
              <Field label="UMRN Code" value={form.umrn_code} onChange={(v) => setForm({ ...form, umrn_code: v })} />
              {form.fro === 'F' && <LogoUploadField umrnCode={form.umrn_code} />}
              <Field label="Horn (dB)" value={form.horn_db} onChange={(v) => setForm({ ...form, horn_db: v })} />
              <Field label="Pass-by Noise (dB)" value={form.pass_by_db} onChange={(v) => setForm({ ...form, pass_by_db: v })} />
            </div>
            <div className="actions" style={{ marginTop: 18, justifyContent: 'space-between' }}>
              {editingId ? (
                <button type="button" className="btn danger" disabled={busy} onClick={() => remove(editingId)}>Delete</button>
              ) : <span />}
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="btn" onClick={() => { setOpen(false); setEditingId(null); }}>Cancel</button>
                <button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
