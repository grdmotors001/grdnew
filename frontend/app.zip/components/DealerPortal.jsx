'use client';
import { useEffect, useMemo, useState } from 'react';
import { get, post, put } from '../lib/api';
import { Palette } from 'lucide-react';
import { THEMES, useTheme } from '../lib/theme';
import { formatDate } from '../lib/date';
import { DealerCashBook } from './DealerCashBook';
import { DealerNewLoanForm } from './DealerNewLoanForm';
import { DealerPaymentPage } from './DealerPaymentPage';
import { DealerCashReceiptPage } from './DealerCashReceiptPage';
import { DealerRepairReceiptPage } from './DealerRepairReceiptPage';
import { ExpensePaymentVoucherPage } from './ExpensePaymentVoucherPage';
import { DealerCustomerInvoicePage } from './DealerCustomerInvoicePage';
import { DealerLedgerPage } from './DealerLedgerPage';
import { DealerPendingSalesPage } from './DealerPendingSalesPage';
import { DealerAllReceiptsPage, DealerAllCustomersPage, DealerExpenseCreatePage, DealerHandoverCreatePage } from './DealerCashBookExtras';
import { ChatWidget } from './ChatWidget';
import { MenuSearch, MobileSearchSheet } from './MenuSearch';
import { HelpButton } from './HelpButton';
import { DealerProfilePage, DealerPasswordPage } from './DealerProfilePage';
import { Field, ErrorBanner } from './ui';
import { TaxInvoicePrintView } from './PrintDocs';

const DEALER_EXPENSE_CATEGORIES = [
  ['pcc', 'PCC'], ['ll', 'LL'], ['dl', 'DL'], ['makhi_commission', 'Makkhi / Commission'],
  ['tea_customer', 'Tea for Customer'], ['tea_staff', 'Tea for Staff'], ['water', 'Water Expense'],
  ['rent', 'Rent Expense'], ['repairing', 'Repairing Expense'], ['other', 'Other Expense'],
];

const dealerHeaderSections = [
  {label:'Stock', items:[['stock','New Stock'],['old-stock','Old Rickshaw Stock'],['battery-stock','Battery Stock'],['seized-vehicles','Seized Vehicle']]},
  {label:'Bahikhata', items:[['cashbook','Cashbook'],['all-customers','All Customers'],['all-receipt','All Receipt'],['all-expenses','All Expenses'],['handover-create','Cash Handover'],['payments','Online Payment']]},
  {label:'Pending', items:[['balance-pending','Balance Pending'],['loan-status','Loan Status']]},
  {label:'All Sale', items:[['invoices','Tax Invoice'],['old-rickshaw-sales','Old Rickshaw Sale'],['battery-sales','Battery Sale'],['challans','Delivery Challan'],['incentive','Incentive Record']]},
  {label:'Loan Status', items:[['loan-status','All'],['loan-pending','Pending'],['loan-approved','Approved'],['loan-billed','Billed']]},
  {label:'Battery Adjustment', items:[['battery-stock','Battery Stock'],['battery-swap','Battery Exchange'],['battery-withdrawal','Battery Withdrawal'],['battery-addition','Battery Fitting']]},
];

const dealerHeaderSectionByTab = {
  stock:'Stock','old-stock':'Stock','battery-stock':'Stock','seized-vehicles':'Stock',
  cashbook:'Bahikhata','all-customers':'Bahikhata','all-receipt':'Bahikhata','all-expenses':'Bahikhata','handover-create':'Bahikhata','cash-handover':'Bahikhata',payments:'Bahikhata',
  'pending-sales':'Pending','balance-pending':'Pending',
  invoices:'All Sale','old-rickshaw-sales':'All Sale','battery-sales':'All Sale',challans:'All Sale',incentive:'All Sale',
  'loan-status':'Loan Status','loan-pending':'Loan Status','loan-approved':'Loan Status','loan-billed':'Loan Status',
  'battery-swap':'Battery Adjustment','battery-withdrawal':'Battery Adjustment','battery-addition':'Battery Adjustment'
};

const nav = [
  ['dashboard', '⌂', 'Dashboard'],
  ['stock', '▣', 'My Stock'],
  ['old-stock', '▥', 'Old Rickshaw Stock'],
  ['battery-stock', '🔋', 'Battery Stock'],
  ['challans', '▤', 'Delivery Challans'],
  ['purchases', '📥', 'Purchases'],
  ['invoices', '▥', 'Tax Invoices'],
  ['pending-sales', '▤', 'Pending'],
  ['balance-pending', '₹', 'Balance Pending'],
  ['expenses-create', '₹', 'Shop Expense'],
  ['all-sale', '▥', 'All Sale'],
  ['loan-status', '✓', 'Loan Status'],
  ['battery-withdrawal', '↘', 'Battery Withdrawal'],
  ['battery-swap', '⇄', 'Battery Swap / Exchange'],
  ['battery-addition', '↗', 'Battery Fit to Rickshaw'],
  ['cashbook', '₹', 'Bahikhata'],
  ['payments', '↔', 'Online Payment'],
  ['ledger', '▤', 'Ledger'],
  ['incentive', '₹', 'Incentive'],
  ['repair-receipt', '🔧', 'Repair Receipt'],
  ['seized-vehicles', '⚠', 'Seized Vehicles'],
  ['receipt-create', '🧾', 'Create Receipt'],
  ['create-sale', '＋', 'Create Sale'],
  ['profile', '👤', 'My Profile'],
  ['password', '🔑', 'Password'],
];

// Old Rickshaw Stock, Battery Stock and Seized Vehicles are no longer
// separate side-nav entries — they live as tabs inside "My Stock" (see
// dealerHeaderSections' Stock group below). Kept in `nav` above so page
// titles/icons still resolve by key; just hidden from the side/mobile menus.
// Battery Withdrawal, Battery Swap/Exchange and Battery Fit (addition) are
// likewise folded into a single "Battery Adjustment" side-nav entry (see
// BATTERY_ADJUSTMENT_KEYS + the sidebarEntries logic below); Battery Stock
// is also reachable from that same group's top sub-menu.
// Create Receipt is available directly from the side/mobile menus for showroom dealers.
const SIDEBAR_HIDDEN_KEYS = new Set(['challans', 'incentive', 'payments', 'balance-pending', 'expenses-create', 'invoices', 'profile', 'password', 'old-stock', 'battery-stock', 'seized-vehicles', 'battery-withdrawal', 'battery-swap', 'battery-addition', 'receipt-create', 'create-sale']);
const BATTERY_ADJUSTMENT_KEYS = ['battery-withdrawal', 'battery-swap', 'battery-addition'];
const STOCK_SECTION_KEYS = ['stock', 'old-stock', 'battery-stock', 'seized-vehicles'];
const ALL_SALE_KEYS = ['invoices', 'old-rickshaw-sales', 'battery-sales', 'challans', 'incentive'];
const LOAN_KEYS = ['loan-status', 'loan-pending', 'loan-approved', 'loan-billed'];
const sidebarKeyOf = (t) => BATTERY_ADJUSTMENT_KEYS.includes(t) ? 'battery-adjustment' : STOCK_SECTION_KEYS.includes(t) ? 'stock' : ALL_SALE_KEYS.includes(t) ? 'all-sale' : LOAN_KEYS.includes(t) ? 'loan-status' : (t === 'balance-pending' || t === 'pending-sales') ? 'pending-sales' : dealerHeaderSectionByTab[t] === 'Bahikhata' ? 'cashbook' : t;

export function DealerPortal({ dealer, onLogout }) {
  const [stock, setStock] = useState(null);
  const [oldStock, setOldStock] = useState(null);
  const [batteryStock, setBatteryStock] = useState(null);
  const [challans, setChallans] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loans, setLoans] = useState([]);
  const [seizedVehicles, setSeizedVehicles] = useState([]);
  const [tab, setTab] = useState('dashboard');
  const [bpSearch, setBpSearch] = useState(''); // Balance Pending: toolbar search + refresh
  const [bpRefresh, setBpRefresh] = useState(0);
  const [openStock, setOpenStock] = useState({}); // mobile My Stock: tapped rows expanded
  const [salePreset, setSalePreset] = useState(null); // stock row -> Create Sale (item already chosen)
  useEffect(() => { if (tab !== 'create-sale') setSalePreset(null); }, [tab]);
  const startSaleFromStock = (preset) => { setSalePreset(preset); setTab('create-sale'); };
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [mobileNav, setMobileNav] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState('');
  const [chatOpen, setChatOpen] = useState(false);
  const { themeId, changeTheme } = useTheme();
  const [showPalette, setShowPalette] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [cashPos, setCashPos] = useState(null);
  const [oldSaleRow, setOldSaleRow] = useState(null);
  const [oldSaleNotice, setOldSaleNotice] = useState('');
  const [pendingTheme, setPendingTheme] = useState(themeId);
  useEffect(() => { setPendingTheme(themeId); }, [themeId]);
  const [selectedPurchase, setSelectedPurchase] = useState(null);
  const canPurchase = dealer.purchase_access === true;
  const canCashBook = (dealer.dealer_category || 'dealer').toLowerCase() === 'showroom';
  const dealerCategory = (dealer.dealer_category || 'dealer').toLowerCase();
  const canCreateSale = ['showroom', 'branch'].includes(dealerCategory);
  // Plain Unregistered dealer: admin hi bill katega, par dealer Old Stock dekh sakta hai aur Pending Sale bana sakta hai
  // (cash = customer manual, finance = approved loan se). Registered dealer ka alag flow (apne naam purchase).
  const isUnregistered = !canCreateSale && String(dealer.registration_type || 'registered').toLowerCase() === 'unregistered';
  const canPendingFlow = canCreateSale || isUnregistered;
  const canLedger = !['showroom', 'branch'].includes(dealerCategory);
  const portalModuleList = Array.isArray(dealer?.portal_modules)
    ? dealer.portal_modules.map((x) => String(x).trim()).filter(Boolean)
    : String(dealer?.portal_modules || '').split(',').map((x) => x.trim()).filter(Boolean);
  const portalModules = new Set(portalModuleList);
  const canRepairReceipt = portalModules.has('repair-receipt');
  const canBatteryWithdrawal = portalModules.has('battery-withdrawal');
  const canBatterySwap = portalModules.has('battery-swap');
  const canBatteryAddition = portalModules.has('battery-addition');
  const canOldRickshawSales = portalModules.has('old-rickshaw-sales');
  const activeHeaderSection = dealerHeaderSectionByTab[tab] || null;
  // Battery Withdrawal / Swap / Fit are grouped into one "Battery Adjustment"
  // side-nav entry. It shows up if the dealer has access to any of the three,
  // and lands on whichever of them is actually enabled for that dealer.
  const canBatteryAdjustment = canBatteryWithdrawal || canBatterySwap || canBatteryAddition;
  const defaultBatteryTab = canBatteryWithdrawal ? 'battery-withdrawal' : canBatterySwap ? 'battery-swap' : 'battery-addition';
  const sidebarEntries = nav.filter(([key]) => !SIDEBAR_HIDDEN_KEYS.has(key) && (key !== 'purchases' || canPurchase) && (key !== 'cashbook' || canCashBook) && (key !== 'receipt-create' || canCashBook) && (key !== 'repair-receipt' || canRepairReceipt) && (key !== 'create-sale' || canCreateSale) && (key !== 'old-rickshaw-sales' || canOldRickshawSales) && (key !== 'ledger' || canLedger) && (key !== 'pending-sales' || canPendingFlow) && (key !== 'old-stock' || canPendingFlow));
  if (canBatteryAdjustment) {
    const batteryEntry = ['battery-adjustment', '🔋', 'Battery Adjustment'];
    const insertAt = sidebarEntries.findIndex(([key]) => key === 'cashbook' || key === 'payments' || key === 'ledger');
    if (insertAt === -1) sidebarEntries.push(batteryEntry); else sidebarEntries.splice(insertAt, 0, batteryEntry);
  }
  // Search: side menu + upar ke sub-menu + dashboard ke quick actions (sirf wahi jo is dealer ko allowed hain).
  const searchAllowed = (key) =>
    (key !== 'incentive' || canCashBook) &&
    (!['cashbook','cash-handover','expenses-create','handover-create'].includes(key) || canCashBook) &&
    (key !== 'battery-withdrawal' || canBatteryWithdrawal) && (key !== 'battery-swap' || canBatterySwap) &&
    (key !== 'battery-addition' || canBatteryAddition) && (key !== 'old-rickshaw-sales' || canOldRickshawSales) && (key !== 'ledger' || canLedger) &&
    (!['old-stock','pending-sales','balance-pending'].includes(key) || canPendingFlow);
  const dealerSearchItems = [
    ...sidebarEntries.map(([key, , label]) => ({ key, label, group: '' })),
    ...dealerHeaderSections.flatMap((sec) => sec.items.filter(([key]) => searchAllowed(key)).map(([key, label]) => ({ key, label, group: sec.label }))),
    { key: 'newloan', label: 'New Loan', group: 'Dashboard' },
    ...(canCreateSale ? [{ key: 'create-sale', label: 'Create Sale', group: 'Dashboard' }] : []),
    ...(canCashBook ? [{ key: 'receipt-create', label: 'Create Receipt', group: 'Dashboard' }] : []),
    ...(canCashBook ? [{ key: 'expenses-create', label: 'Shop Expense', group: 'Dashboard' }] : []),
  ];
  const isBatteryAdjustmentActive = BATTERY_ADJUSTMENT_KEYS.includes(tab);
  const goToSidebarTab = (key) => {
    if (key === 'all-sale') setTab('invoices');
    else if (key === 'pending-sales') setTab('balance-pending');
    else setTab(key === 'battery-adjustment' ? defaultBatteryTab : key);
  };

  // Invoice banne ke baad My Stock (bina bill wali gaadiyan) aur Tax Invoices dono turant refresh.
  const reloadAfterInvoice = () => {
    get('/dealer/stock', { noClientCache: true }).then(setStock).catch(() => {});
    get('/dealer/tax-invoices', { noClientCache: true }).then((r) => setInvoices(r.invoices || [])).catch(() => {});
  };

  const loadLoanStatus = async () => {
    try {
      const l = await get('/dealer/loan-status', { timeoutMs: 60000, noClientCache: true });
      setLoans(l.applications || []);
    } catch {
      setLoans([]);
    }
  };

  useEffect(() => {
    // Dealer portal must remain usable if one optional data module is unavailable.
    // Load each section independently instead of turning one API failure into a
    // permanent full-page error banner.
    setError('');
    const loads = [
      ['stock', () => get('/dealer/stock').then(setStock)],
      ['battery-stock', () => get('/dealer/battery-stock').then(setBatteryStock)],
      ['delivery-challans', () => get('/dealer/delivery-challans').then(r => setChallans(r.challans || []))],
      ['tax-invoices', () => get('/dealer/tax-invoices').then(r => setInvoices(r.invoices || []))],
    ];
    if (canPendingFlow) loads.push(['old-rickshaws', () => get('/dealer/old-rickshaws').then(setOldStock)]);
    if (canCashBook) loads.push(['cash-position', () => get('/dealer/cash-position', { noClientCache: true }).then(setCashPos)]);
    loads.forEach(([name, load]) => load().catch((e) => {
      console.warn('[dealer-portal] optional module failed:', name, e);
    }));
    loadLoanStatus();
    get('/dealer/seized-vehicles')
      .then((r) => setSeizedVehicles(r.vehicles || []))
      .catch(() => setSeizedVehicles([]));
  }, []);

  const q = search.trim().toLowerCase();
  const filteredStock = (stock?.vehicles || []).filter(v => [v.date,v.challan_no,v.chassis_no,v.model_name,v.battery_maker,v.colour].join(' ').toLowerCase().includes(q));
  const filteredOldStock = (oldStock?.rickshaws || []).filter(v => [v.sale_date,v.vehicle_reg_no,v.model_name,v.owner_name,v.sp_no].join(' ').toLowerCase().includes(q));
  const unsoldOldStock = filteredOldStock.filter(v => String(v.status||'').toLowerCase() === 'available');
  const filteredBatteryStock = (batteryStock?.batteries || []).filter(v => [v.date,v.battery_maker,v.battery_no,v.reference_no].join(' ').toLowerCase().includes(q));
  const filteredChallans = challans.filter(v => [v.date,v.challan_no,v.chassis_no,v.product_name,v.destination].join(' ').toLowerCase().includes(q));
  const filteredInvoices = invoices.filter(v => [v.date,v.bill_no,v.chassis_no,v.product_name,v.buyer_name].join(' ').toLowerCase().includes(q));

  const latest = useMemo(() => [
    ...challans.map(x => ({type:'Delivery Challan',no:x.challan_no,date:x.date,text:x.chassis_no||x.product_name})),
    ...invoices.map(x => ({type:'Tax Invoice',no:x.bill_no,date:x.date,text:x.chassis_no||x.product_name}))
  ].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,5), [challans,invoices]);

  const dealerName = String(dealer?.name || dealer?.full_name || 'Dealer');
  const dealerCode = String(dealer?.code || dealer?.login_id || dealer?.dealer_code || '');
  // Salesman logins open the portal of their dealer: show the salesman's own name, dealer name goes underneath.
  const isSalesman = Boolean(dealer?.is_salesman || dealer?.role === 'salesman');
  const personName = isSalesman ? String(dealer?.salesman || 'Salesman') : dealerName;

  const standaloneForm =
    (tab === 'create-sale' && canCreateSale) ? <DealerCreateSaleForm key={salePreset ? (salePreset.kind + (salePreset.chassis_no || salePreset.battery_no || '')) : 'free'} dealer={dealer} stock={stock} oldStock={oldStock} batteryStock={batteryStock} preset={salePreset} onBack={() => setTab(salePreset ? (salePreset.kind === 'battery' ? 'battery-stock' : 'stock') : 'dashboard')} /> :
    tab === 'newloan' ? <DealerNewLoanForm onBack={() => setTab('dashboard')} /> :
    (tab === 'expenses-create' && canCashBook) ? <div className="dealerPage"><div style={{marginBottom:10}}><button type="button" className="btn" onClick={() => setTab('dashboard')}>← Back</button></div><DealerExpenseCreatePage /></div> :
    (tab === 'battery-withdrawal' && canBatteryWithdrawal) ? <DealerBatteryWithdrawal dealer={dealer} onBack={() => setTab('dashboard')} /> :
    (tab === 'battery-swap' && canBatterySwap) ? <DealerBatterySwap dealer={dealer} onBack={() => setTab('dashboard')} /> :
    (tab === 'battery-addition' && canBatteryAddition) ? <DealerBatteryAddition dealer={dealer} onBack={() => setTab('dashboard')} /> :
    ALL_SALE_KEYS.includes(tab) ? <DealerAllSale tab={tab} dealer={dealer} invoices={invoices} challans={filteredChallans} canCashBook={canCashBook} canOldRickshawSales={canOldRickshawSales} /> :
    LOAN_KEYS.includes(tab) ? <DealerLoanStatus tab={tab} rows={loans} onRefresh={loadLoanStatus} /> :
    (tab === 'ledger' && canLedger) ? <DealerLedgerPage /> :
    (tab === 'customer-invoice' && canPurchase) ? <DealerCustomerInvoicePage challan={selectedPurchase} dealer={dealer} onDone={reloadAfterInvoice} onBack={() => setTab('purchases')} /> :
    null;

  return (<div className="dealerShell">
    <style>{`
      .dealerOldSalePage{padding:4px 0 80px}
      .dealerOldSaleHeader,.dealerOldStockHead{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:14px;padding:4px 2px}
      .dealerOldSaleKicker,.dealerOldStockKicker{font-size:10px;font-weight:900;letter-spacing:1px;color:var(--accent);text-transform:uppercase}
      .dealerOldSaleHeader h2,.dealerOldStockHead h2{margin:2px 0 4px;font-size:24px;color:#172b45}
      .dealerOldSaleHeader p,.dealerOldStockHead p{margin:0;color:#748297;font-size:12px}
      .dealerOldSaleActions{display:flex;gap:8px;flex-wrap:wrap}
      .dealerOldSaleCard,.dealerOldStockCard{border:1px solid #e4e9ef;border-radius:14px;background:#fff;box-shadow:0 5px 18px rgba(31,55,79,.06);overflow:hidden}
      .dealerOldSaleSectionTitle{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:16px;border-bottom:1px solid #edf1f5}
      .dealerOldSaleSectionTitle strong{display:block;font-size:15px;color:#1f334a}.dealerOldSaleSectionTitle span{display:block;margin-top:3px;font-size:11px;color:#7b8898}
      .dealerOldSaleCount{min-width:30px!important;width:30px;height:30px;border-radius:50%;display:grid!important;place-items:center;background:color-mix(in srgb,var(--accent) 12%,white);color:var(--accent)!important;font-weight:800}
      .dealerOldSaleTableWrap,.dealerOldStockTableWrap{overflow-x:auto}.dealerOldSaleTable,.dealerOldStockTable{min-width:720px}
      .dealerOldSaleStatus{display:inline-flex!important;padding:5px 8px;border-radius:999px;background:#fff7df;color:#8a6500!important;font-size:10px!important;font-weight:800}.dealerOldSaleEnter{white-space:nowrap}
      .dealerOldSaleModal{z-index:99999;padding:16px;overflow:auto;align-items:center;isolation:isolate}.dealerOldSaleModalBox{width:min(760px,100%);max-height:calc(100vh - 32px);overflow:auto;padding:20px;border-radius:18px;box-sizing:border-box;position:relative;z-index:1}
      .dealerOldSaleModalHead{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:14px}.dealerOldSaleModalHead h2{margin:2px 0 4px;font-size:22px}.dealerOldSaleModalHead p{margin:0;color:#748297;font-size:12px}
      .dealerOldSaleClose{border:1px solid #dbe2ea;background:#fff;border-radius:10px;width:38px;height:38px;font-size:24px;line-height:1;cursor:pointer;color:#516174}
      .dealerOldSaleSummary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:16px}.dealerOldSaleSummary>div{background:#f7faff;border:1px solid #e3ebf5;border-radius:10px;padding:10px 12px;min-width:0}.dealerOldSaleSummary span{display:block;font-size:9px;text-transform:uppercase;letter-spacing:.5px;color:#7b8a9c}.dealerOldSaleSummary b{display:block;margin-top:3px;font-size:12px;color:#21364d;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .dealerOldSaleFormGrid{gap:12px}.dealerOldSaleFormGrid .field label{font-size:11px;font-weight:700;color:#63748a}.dealerOldSaleFormGrid .input{min-height:44px;box-sizing:border-box}
      .dealerOldSaleModalFooter{display:flex;justify-content:flex-end;gap:8px;margin-top:18px;padding-top:14px;border-top:1px solid #edf1f5}.dealerOldSaleSave,.dealerOldSaleCancel{min-width:110px}
      .dealerOldStockPage{padding:4px 0 80px}.dealerOldStockGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:14px}.dealerOldStockStat{background:#fff;border:1px solid #e4e9ef;border-radius:12px;padding:13px 15px;box-shadow:0 4px 14px rgba(31,55,79,.04)}.dealerOldStockStat span{display:block;color:#718096;font-size:10px;text-transform:uppercase;font-weight:800;letter-spacing:.4px}.dealerOldStockStat b{display:block;margin-top:3px;color:#1f334a;font-size:22px}
      .dealerOldStockStatus{display:inline-flex!important;padding:5px 8px;border-radius:999px;font-size:10px!important;font-weight:800}.dealerOldStockStatus.available{background:#eaf8ef;color:#19733a!important}.dealerOldStockStatus.sold{background:#edf1f5;color:#59697b!important}
      @media(max-width:700px){.dealerOldSalePage,.dealerOldStockPage{padding:2px 0 76px}.dealerOldSaleHeader,.dealerOldStockHead{display:block}.dealerOldSaleHeader h2,.dealerOldStockHead h2{font-size:21px}.dealerOldSaleActions{margin-top:10px}.dealerOldSaleActions .btn{flex:1}.dealerOldSaleSectionTitle{padding:13px}.dealerOldSaleSectionTitle span{font-size:10px;max-width:260px}.dealerOldSaleTable,.dealerOldStockTable{min-width:0;width:100%}.dealerOldSaleTable thead,.dealerOldStockTable thead{display:none}.dealerOldSaleTable tbody,.dealerOldStockTable tbody,.dealerOldSaleTable tr,.dealerOldStockTable tr,.dealerOldSaleTable td,.dealerOldStockTable td{display:block;width:100%;box-sizing:border-box}.dealerOldSaleTable tr,.dealerOldStockTable tr{padding:11px 12px;border-bottom:1px solid #edf1f5}.dealerOldSaleTable td,.dealerOldStockTable td{display:flex!important;justify-content:space-between;gap:14px;border:0!important;padding:6px 0!important;text-align:right}.dealerOldSaleTable td:before,.dealerOldStockTable td:before{content:attr(data-label);font-weight:700;color:#738195;text-align:left}.dealerOldSaleTable td:last-child{padding-top:10px!important}.dealerOldSaleEnter{width:100%}.dealerOldSaleSummary{grid-template-columns:1fr 1fr}.dealerOldSaleSummary>div:last-child{grid-column:1/-1}.dealerOldSaleModal{padding:8px;align-items:flex-end}.dealerOldSaleModalBox{max-height:calc(100vh - 16px);padding:16px;border-radius:16px}.dealerOldSaleModalHead h2{font-size:19px}.dealerOldSaleFormGrid{grid-template-columns:1fr!important}.dealerOldSaleModalFooter{position:sticky;bottom:0;background:#fff;margin:16px -16px -16px;padding:12px 16px;z-index:2}.dealerOldSaleSave,.dealerOldSaleCancel{flex:1}.dealerOldStockGrid{grid-template-columns:1fr 1fr}.dealerOldStockStat:first-child{grid-column:1/-1}}
      .grdFormPage{padding:12px}
      .grdFormPage .dealerPanel{max-width:980px;background:#fff;border:1px solid #e4e9ef;border-radius:14px;box-shadow:0 5px 18px rgba(31,55,79,.06);padding:16px}
      .grdFormPage .dealerPanelHead{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
      .grdFormPage .dealerPanelHead h3{margin:0;font-size:18px;color:#172b45}
      .grdFormPage .dealerPanelHead p{margin:3px 0 0;color:#748297;font-size:11px}
      .grdFormPage .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
      .grdFormPage .grid>div{min-width:0}
      .grdFormPage label{display:flex;flex-direction:column;gap:6px;font-size:11px;font-weight:700;color:#65758a}
      .grdFormPage .input{width:100%;min-height:40px;border:1px solid #d7e0e9;border-radius:8px;background:#fff;box-sizing:border-box;padding:9px 11px;font-size:12px;color:#24384d}
      .grdFormPage .input:focus{outline:none;border-color:#2d79df;box-shadow:0 0 0 2px rgba(45,121,223,.10)}
      .grdFormPage .card{border:1px solid #e2e8ef;border-radius:10px;background:#fbfdff}
      .grdFormPage .btn{border:1px solid #d8e0e8;border-radius:8px;background:#fff;color:#33475b;padding:8px 13px;font-size:11px;font-weight:700;cursor:pointer}
      .grdFormPage .btn.primary{border-color:#246fe8;background:#246fe8;color:#fff}
      .grdFormPage .error{border:1px solid #f3cccc;background:#fff3f3;color:#a52b2b;border-radius:8px;padding:8px 10px;font-size:11px;margin-bottom:12px}
      .grdFormPage .actions{display:flex;gap:8px;margin-top:14px}
      @media(max-width:700px){.grdFormPage{padding:0}.grdFormPage .dealerPanel{border-radius:0 0 12px 12px;padding:13px}.grdFormPage .grid{grid-template-columns:1fr;gap:11px}.grdFormPage .dealerPanelHead h3{font-size:15px}.grdFormPage .input{min-height:38px;font-size:11px}}
      .dealerCreateSalePage{padding:12px}
      .dealerCreateSalePanel{max-width:760px}
      .dealerCreateSaleGrid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
      .dealerCreateSaleGrid label{display:flex;flex-direction:column;gap:6px;font-size:11px;font-weight:800;color:#30445b}
      .dealerCreateSaleGrid input,.dealerCreateSaleGrid select{width:100%;min-height:42px;box-sizing:border-box}
      .dealerCreateSaleItemField{grid-column:1/-1}
      .dealerCreateSaleActions{justify-content:flex-end}
      .dealerCreateSalePreview{margin-top:16px;border:1px solid #dfe7f0;border-radius:12px;background:#f8fbff;overflow:hidden}
      .dealerCreateSalePreviewHead{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:11px 13px;border-bottom:1px solid #e5ebf2;color:#24384d;font-size:12px}
      .dealerCreateSalePreviewHead span{font-size:10px;font-weight:800;color:#246fe8}
      .dealerCreateSalePreviewGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;padding:13px}
      .dealerCreateSalePreviewGrid>div{min-width:0}
      .dealerCreateSalePreviewGrid span{display:block;font-size:9px;text-transform:uppercase;letter-spacing:.45px;color:#718096;font-weight:800}
      .dealerCreateSalePreviewGrid b{display:block;margin-top:3px;font-size:12px;color:#24384d;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      @media(max-width:620px){.dealerCreateSalePage{padding:0}.dealerCreateSalePanel{border-radius:0 0 12px 12px;padding:13px}.dealerCreateSaleGrid{grid-template-columns:1fr}.dealerCreateSaleItemField{grid-column:auto}.dealerCreateSaleActions{position:sticky;bottom:0;background:#fff;padding-top:12px}.dealerCreateSalePreviewGrid{grid-template-columns:1fr 1fr}.dealerCreateSalePreviewGrid>div:last-child{grid-column:1/-1}}
      .dealerPortalHeaderNav{display:flex;gap:8px;align-items:stretch;overflow-x:auto;border-bottom:1px solid #e3e8f0;background:#fff;padding:7px 0 8px;scrollbar-width:none;min-height:50px}
      .dealerPortalHeaderNav::-webkit-scrollbar{display:none}
      .dealerPortalHeaderGroup{display:flex;flex-direction:column;gap:3px;flex:0 0 auto;padding:0 8px}
      .dealerPortalHeaderLabel{font-size:9px;font-weight:900;letter-spacing:.55px;text-transform:uppercase;color:#6b7b8f;padding:0 5px}
      .dealerPortalHeaderItems{display:flex;gap:5px}
      .dealerPortalHeaderItem{border:1px solid #e2e8ef;background:#f8fafc;color:#30445b;border-radius:7px;padding:6px 10px;font-size:10px;font-weight:700;white-space:nowrap;cursor:pointer}
      .dealerPortalHeaderItem:hover,.dealerPortalHeaderItem.active{background:#eaf2ff;border-color:#9fc2fa;color:#155dcc}
      .dealerTopbar.grdTopHeader{margin:-28px -32px 22px;padding:0 18px;overflow:visible}
      .dealerTopbar.grdTopHeader .dealerEyebrow{color:#ffffffb0}
      .dealerTopbar.grdTopHeader h1{color:#fff}
      .dealerTopTitleBlock{min-width:0;flex:1 1 auto;overflow:hidden}
      .dealerTopTitleBlock h1{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      @media(max-width:1100px){.dealerTopbar.grdTopHeader{margin:-24px -24px 20px}}
      @media(max-width:700px){.dealerTopbar.grdTopHeader{margin:-14px -14px 14px}.dealerTopbar.grdTopHeader .dealerMobileMenu{display:flex;background:#ffffff1a;border-color:#ffffff40;color:#fff;flex:none}.dealerTopbar.grdTopHeader .grdHeaderUser strong{display:none}}
      .dealerBatteryCard{margin-top:6px}
      .dealerBatteryFormGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px 16px;align-items:end}
      .dealerBatteryFormGrid label{display:flex;flex-direction:column;gap:6px;font-size:11px;font-weight:800;color:#30445b}
      .dealerBatteryFormGrid input,.dealerBatteryFormGrid select{width:100%;min-height:42px;box-sizing:border-box}
      .dealerBatteryFormActions{display:flex;justify-content:flex-start;margin-top:16px}
      @media(max-width:900px){.dealerBatteryFormGrid{grid-template-columns:repeat(2,minmax(0,1fr))}}
      @media(max-width:620px){.dealerBatteryFormGrid{grid-template-columns:1fr}}
      @media(max-width:700px){.dealerPortalHeaderNav{margin:0 -10px;padding-left:10px;padding-right:10px}.dealerPortalHeaderItem{font-size:9px;padding:6px 8px}.dealerPortalHeaderLabel{font-size:8px}}
      .dealerDashboardStats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.dealerDashStat{border:1px solid #e1e7ef;border-radius:11px;background:#fbfdff;padding:12px;text-align:left;cursor:pointer}.dealerDashStat span{display:block;color:#748297;font-size:10px;font-weight:700}.dealerDashStat b{display:block;margin-top:4px;color:#1f334a;font-size:22px}.dealerDashboardActions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.dealerTablePager{display:flex;align-items:center;justify-content:flex-end;gap:10px;padding:10px;border-top:1px solid #edf1f5;font-size:11px;color:#66758a}@media(max-width:700px){.dealerDashboardStats{grid-template-columns:1fr 1fr}.dealerTablePager{justify-content:center}}
      .dealerUserMenuWrap{position:relative}.dealerUserBtn{background:transparent;border:0;color:inherit;font:inherit;cursor:pointer}.dealerUserMenuBackdrop{position:fixed;inset:0;z-index:40}.dealerUserMenu{position:absolute;right:0;top:calc(100% + 8px);z-index:41;min-width:210px;background:var(--card,#fff);color:var(--ink,#172b45);border:1px solid var(--line,#e4e9ef);border-radius:12px;box-shadow:0 12px 30px rgba(0,0,0,.22);padding:6px;display:flex;flex-direction:column}.dealerUserMenuHead{padding:8px 10px 10px;border-bottom:1px solid var(--line,#e4e9ef);margin-bottom:4px;display:flex;flex-direction:column}.dealerUserMenuHead small{color:var(--muted,#748297);font-size:11px}.dealerUserMenu button{background:transparent;border:0;color:inherit;text-align:left;padding:9px 10px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer}.dealerUserMenu button:hover{background:color-mix(in srgb,var(--accent,#0a7) 12%,transparent)}
      @media(max-width:700px){.dealerUserMenu{position:fixed;right:10px;top:56px}}
    `}</style>
    <aside className="dealerSidebar">
      <div className="dealerBrand"><div className="dealerBrandMark">G</div><div><strong>G.R.D. MOTORS</strong><span>Dealer Portal</span></div></div>
      <MenuSearch items={dealerSearchItems} onPick={goToSidebarTab} variant="dark" recentKey="grd_dealer_recent_menu" />
      <nav className="dealerSideNav">{sidebarEntries.map(([key,icon,label]) =>
        <button key={key} className={'dealerNavItem'+(sidebarKeyOf(tab)===key?' active':'')} onClick={()=>goToSidebarTab(key)}><span className="dealerNavIcon">{icon}</span><span>{label}</span></button>
      )}</nav>
      <button className="dealerLogout" onClick={onLogout}><span>↪</span> Log Out</button>
    </aside>

    <main className="dealerMain">
      <header className="dealerTopbar grdTopHeader">
        <style>{`@media(max-width:700px){.dealerTopbar.grdTopHeader .dealerMobileMenu,.dealerTopbar .grdHelpWrap,.dealerTopbar .grdHeaderIcon[aria-label="Notifications"]{display:none!important}}`}</style>
        <button className="dealerMobileMenu" onClick={()=>setMobileNav(v=>!v)}>☰</button>
        {activeHeaderSection ? (() => {
          const section = dealerHeaderSections.find(s => s.label === activeHeaderSection);
          if (!section) return null;
          const items = section.items.filter(([key]) =>
            (key !== 'incentive' || canCashBook) &&
            (key !== 'cashbook' && key !== 'cash-handover' && key !== 'expenses-create' && key !== 'handover-create' || canCashBook) &&
            (key !== 'battery-withdrawal' || canBatteryWithdrawal) &&
            (key !== 'battery-swap' || canBatterySwap) &&
            (key !== 'battery-addition' || canBatteryAddition) &&
            (key !== 'old-rickshaw-sales' || canOldRickshawSales) &&
            (!['old-stock','balance-pending'].includes(key) || canPendingFlow)
          );
          return (
            <div className={"moduleStrip dealerModuleStrip"+(['Bahikhata','Battery Adjustment','Stock','Pending'].includes(activeHeaderSection)?' bkStripHide':'')} aria-label={activeHeaderSection}>
              {items.map(([key,label]) => (
                <button type="button" key={key}
                  className={'moduleStripItem'+(tab===key?' active':'')}
                  onClick={()=>setTab(key)}>
                  {label}
                </button>
              ))}
            </div>
          );
        })() : (
          <div className="dealerTopTitleBlock">
            <h1>{tab==='dashboard'?'Dashboard':nav.find(x=>x[0]===tab)?.[2]||'Dealer Panel'}</h1>
          </div>
        )}
        <div className="grdHeaderActions">
          <span className="grdHelpWrap" style={{display:'contents'}}><HelpButton storageKey="grd_dealer_help_seen_v1" sections={[
            { title: 'Search & Navigation', rows: [
              ['Ctrl|K', 'Menu search kholo (kisi bhi option ko naam se dhoondo)'],
              ['/', 'Menu search kholo (jab koi box khula na ho)'],
              ['↑|↓', 'Search results me upar / neeche'],
              ['Enter', 'Chuna hua option kholo'],
              ['Esc', 'Search saaf karo / band karo'],
            ] },
            { title: 'Dashboard se jaldi kaam', rows: [
              ['New Loan', 'Naya loan application'],
              ...(canCreateSale ? [['Create Sale', 'Naya sale (Showroom / Branch)']] : []),
              ...(canCashBook ? [['Create Receipt', 'Cash receipt (Showroom)'], ['Shop Expense', 'Shop ka kharcha (Showroom)']] : []),
            ] },
          ]} /></span>
          <button type="button" className="grdHeaderIcon" title="Office Chat" aria-label="Office Chat" onClick={()=>{ if (window.innerWidth <= 700) window.location.href = '/chat'; else setChatOpen(v=>!v); }}>💬</button>
          <button type="button" className="grdHeaderIcon" title="Notifications" aria-label="Notifications">🔔</button>
          <div className="themePaletteWrap">
            <button type="button" className="themeColorButton" onClick={() => setShowPalette(v => !v)} title="Themes" aria-label="Open themes"><Palette size={14}/></button>
            {showPalette && <div className="themeChooser" role="dialog" aria-label="Choose theme">
              {THEMES.map(theme => <button
                key={theme.id}
                type="button"
                className={'themeCard'+(pendingTheme===theme.id?' selected':'')}
                style={{background:`linear-gradient(90deg, ${theme.colors.primary} 0 33.333%, ${theme.colors.accent} 33.333% 66.666%, ${theme.colors.bg} 66.666% 100%)`}}
                title={theme.name}
                aria-label={theme.name}
                onClick={() => { changeTheme(theme.id); setPendingTheme(theme.id); setShowPalette(false); }}
              />)}
            </div>}
          </div>
          <div className="dealerUserMenuWrap">
            <button type="button" className="grdHeaderUser dealerUserBtn" onClick={()=>setShowUserMenu(v=>!v)} aria-haspopup="menu" aria-expanded={showUserMenu}><div className="grdHeaderAvatar">{personName.slice(0,1).toUpperCase()}</div><strong>{personName}</strong><span>⌄</span></button>
            {showUserMenu && <>
              <div className="dealerUserMenuBackdrop" onClick={()=>setShowUserMenu(false)} />
              <div className="dealerUserMenu" role="menu">
                <div className="dealerUserMenuHead"><strong>{personName}</strong><small>{isSalesman ? dealerName : dealerCode}</small></div>
                <button type="button" role="menuitem" onClick={()=>{setTab('profile');setShowUserMenu(false)}}>👤 My Profile</button>
                <button type="button" role="menuitem" onClick={()=>{setTab('password');setShowUserMenu(false)}}>🔑 Change Password</button>
                <button type="button" role="menuitem" onClick={()=>{setShowUserMenu(false);onLogout()}}>↪ Log Out</button>
              </div>
            </>}
          </div>
          <button className="btn dealerLogoutTop" onClick={onLogout}>Log Out</button>
        </div>
      </header>
      {mobileNav && (() => {
        const GROUPS = [
          ['Roz ka kaam', ['dashboard','stock','pending-sales','all-sale']],
          ['Paisa / Hisab', ['cashbook','payments','ledger','incentive','repair-receipt']],
          ['Aur options', ['battery-adjustment','loan-status','profile','password']],
        ];
        const byKey = new Map([...sidebarEntries, ...nav.filter(([k]) => k === 'profile' || k === 'password')].map((e) => [e[0], e]));
        const used = new Set(GROUPS.flatMap(([, ks]) => ks));
        const extra = sidebarEntries.filter((e) => !used.has(e[0])).map((e) => e[0]);
        const groups = GROUPS.map(([label, ks]) => [label, (label === 'Aur options' ? [...ks, ...extra] : ks).map((k) => byKey.get(k)).filter(Boolean)]).filter(([, es]) => es.length);
        const activeKey = sidebarKeyOf(tab);
        const current = groups.find(([, es]) => es.some((e) => e[0] === activeKey))?.[0] || groups[0]?.[0];
        const opened = openGroup || current;
        return <div className="dealerMobileNav">
          <MenuSearch items={dealerSearchItems} onPick={(k)=>{goToSidebarTab(k);setMobileNav(false)}} variant="light" recentKey="grd_dealer_recent_menu" />
          {groups.map(([label, es]) => <div key={label}>
            <button type="button" className="dealerNavItem" style={{width:'100%',justifyContent:'space-between',fontWeight:800}} onClick={()=>setOpenGroup(opened===label?'__none':label)} aria-expanded={opened===label}>
              <span>{label} <small style={{opacity:.6}}>({es.length})</small></span><span>{opened===label?'▾':'▸'}</span>
            </button>
            {opened===label && es.map(([key,icon,lbl]) => <button key={key} className={'dealerNavItem'+(activeKey===key?' active':'')} style={{paddingLeft:22}} onClick={()=>{goToSidebarTab(key);setMobileNav(false)}}><span className="dealerNavIcon">{icon}</span>{lbl}</button>)}
          </div>)}
        </div>;
      })()}
      {error && <div className="error dealerError">{error}</div>}

      {['Bahikhata','Battery Adjustment','Stock','Pending'].includes(activeHeaderSection) && <>
        <style>{`
          .bkBlocks{display:none}
          .mxChev,.mxOnlyMobile{display:none}
          @media(max-width:700px){
            .mxHead{flex-direction:row!important;align-items:flex-start!important;justify-content:space-between;gap:10px}
            .mxHead p{display:none}
            .mxTabs{display:grid!important;grid-template-columns:1fr 1fr;gap:8px!important}
            .mxTabs .btn{width:100%;justify-content:center;text-align:center;padding:10px 6px;font-size:13px;line-height:1.2;white-space:normal}
            .mxHide{display:none!important}
            .mxTools{display:grid!important;grid-template-columns:minmax(0,1fr) auto;gap:8px;width:100%}
            .mxTools .dealerSearch{grid-column:1/-1;order:3;width:100%}
            .mxOnlyMobile{display:inline-flex}
            .mxTable .table tfoot{display:none}
            .mxTable .table tbody tr.mxRow{display:grid;column-gap:10px;row-gap:3px;align-items:center;padding:12px 14px;cursor:pointer}
            .mxTable .table tbody tr.mxRow.open{border-color:var(--accent)}
            .mxTable .table tbody tr.mxRow.three{grid-template-columns:auto minmax(0,1fr) auto}
            .mxTable .table tbody tr.mxRow.two{grid-template-columns:minmax(0,1fr) auto}
            .mxTable .table tbody tr.mxRow td:before{display:none}
            .mxTable .table tbody tr.mxRow td.mxK{display:block;border:0;padding:0;min-width:0;overflow-wrap:anywhere}
            .mxTable tr.three td.k1{grid-area:1/1}.mxTable tr.three td.k2{grid-area:1/2;font-size:14px}.mxTable tr.three td.k3{grid-area:1/3;text-align:right;font-size:12px;color:var(--muted);white-space:nowrap}
            .mxTable tr.two td.k1{grid-area:1/1;font-size:14px}.mxTable tr.two td.k2{grid-area:1/2;text-align:right;font-size:14px}
            .mxTable tr.two td.k3{grid-area:2/1;font-size:12px;color:var(--muted)}.mxTable tr.two td.k4{grid-area:2/2;text-align:right;font-size:12px;color:var(--muted);white-space:nowrap}
            .mxTable .mxPg{display:inline-block;min-width:34px;text-align:center;padding:3px 7px;border-radius:8px;background:color-mix(in srgb,var(--accent) 14%,transparent);font-weight:800;font-size:12px}
            .mxTable .mxChev{display:inline-block;margin-left:6px;font-size:11px;transition:transform .15s}
            .mxTable tr.open .mxChev{transform:rotate(180deg)}
            .mxTable .table tbody tr.mxRow td.mxM{display:none}
            .mxTable .table tbody tr.mxRow.open td.mxM{display:flex;grid-column:1/-1;border-bottom:0;border-top:1px solid var(--line);padding:9px 0}
            .mxTable .table tbody tr.mxRow.open td.mxM:before{display:block}
            .mxTable .table tbody tr.mxRow.open td.mxAct{flex-wrap:wrap;gap:6px}
            .mxTable .table tbody tr.mxRow.open td.mxAct:before{display:none}
            .mxTable tr:not(.open) .mxPhone{display:none}
            .dealerModuleStrip.bkStripHide{display:none}
            .bkBlocks{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:4px 0 14px}
            .bkBlock{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:68px;padding:8px 4px;border-radius:14px;border:1px solid var(--line);background:var(--card);color:var(--ink);font-size:12px;font-weight:700;line-height:1.2;text-align:center;cursor:pointer}
            .bkBlock i{font-style:normal;font-size:20px;line-height:1}
            .bkBlock.active{background:var(--accent);border-color:var(--accent);color:#fff}
            .bkBlock:active{transform:scale(.97)}
          }
        `}</style>
        {['Bahikhata','Battery Adjustment','Stock','Pending'].includes(activeHeaderSection) && <div className="bkBlocks" role="tablist" aria-label={activeHeaderSection} style={{gridTemplateColumns:'repeat(2,minmax(0,1fr))'}}>
          {(activeHeaderSection==='Stock'
            ? [['stock','📦'],['old-stock','🛺'],['battery-stock','🔋'],['seized-vehicles','🚫']]
            : activeHeaderSection==='Pending'
            ? [['balance-pending','💰'],['loan-status','🏦']]
            : activeHeaderSection==='Battery Adjustment'
            ? [['battery-swap','🔄'],['battery-withdrawal','⬇️'],['battery-addition','🔌'],['battery-stock','🔋']]
            : [['cashbook','📒'],['all-expenses','💸'],['handover-create','🤝'],['payments','📲']])
            .map(([key,icon])=>{const it=dealerHeaderSections.find(x=>x.label===activeHeaderSection).items.find(x=>x[0]===key); return it?{key,icon,label:it[1]}:null})
            .filter(b=>b
              && (!['cashbook','handover-create'].includes(b.key) || canCashBook)
              && (!['old-stock','balance-pending'].includes(b.key) || canPendingFlow) && (b.key!=='battery-swap' || canBatterySwap) && (b.key!=='battery-withdrawal' || canBatteryWithdrawal) && (b.key!=='battery-addition' || canBatteryAddition))
            .map(b=><button type="button" role="tab" key={b.key} className={'bkBlock'+((tab===b.key||(b.key==='handover-create'&&tab==='cash-handover'))?' active':'')} aria-selected={tab===b.key} onClick={()=>setTab(b.key)}><i>{b.icon}</i><span>{b.label}</span></button>)}
        </div>}
      </>}

      <nav className="dealerBottomNav dealerBottomNavForce" aria-label="Dealer bottom navigation">
        {nav.filter(x=>['dashboard','stock','pending-sales'].includes(x[0]) && (x[0] !== 'pending-sales' || canPendingFlow)).map(([key,icon,label])=>
          <button type="button" key={key} className={sidebarKeyOf(tab)===key?'active':''} onClick={()=>{goToSidebarTab(key);setMobileNav(false)}}>
            <span>{icon}</span><small>{label}</small>
          </button>
        )}
        {canCashBook
          ? <button type="button" className={activeHeaderSection==='Bahikhata'?'active':''} onClick={()=>{setMobileNav(false);setTab('cashbook')}}><span>📒</span><small>Bahikhata</small></button>
          : <button type="button" onClick={()=>{setMobileNav(false);setSearchOpen(true)}}><span>🔍</span><small>Search</small></button>}
        {canBatteryAdjustment
          ? <button type="button" className={activeHeaderSection==='Battery Adjustment'?'active':''} onClick={()=>{setMobileNav(false);setTab(defaultBatteryTab)}}><span>🔋</span><small>Battery</small></button>
          : <button type="button" className={mobileNav?'active':''} onClick={()=>setMobileNav(v=>!v)}><span>☰</span><small>More</small></button>}
      </nav>
      <MobileSearchSheet open={searchOpen} onClose={()=>setSearchOpen(false)} items={dealerSearchItems} onPick={goToSidebarTab} recentKey="grd_dealer_recent_menu" />
      {standaloneForm || <>
      {tab==='dashboard' && <DealerDashboard dealerName={personName} stockCount={stock?.count} challanCount={challans.length} invoiceCount={invoices.length} loanCount={loans.length} latest={latest} onNewLoan={()=>setTab('newloan')} onOpen={goToSidebarTab} cashPos={cashPos} canCashBook={canCashBook} canCreateSale={canCreateSale}/>} 
      {tab==='profile' && <DealerProfilePage dealer={dealer}/>}
      {tab==='password' && <DealerPasswordPage/>}
      {tab!=='dashboard' && tab!=='profile' && tab!=='password' && <>
        <div className="dealerContentToolbar">
          <div className="dealerPageIntro"><span className="dealerSectionIcon">{nav.find(x=>x[0]===tab)?.[1]}</span><div><strong>{nav.find(x=>x[0]===tab)?.[2]}</strong><small>Dealer-wise records</small></div></div>
          {tab==='balance-pending' ? <div style={{display:'flex',gap:8,alignItems:'center',flex:'none',width:'min(460px,100%)',minWidth:0}}><input className="input dealerSearch" style={{flex:1,minWidth:0}} placeholder="Search page no. / name / mobile…" value={bpSearch} onChange={e=>setBpSearch(e.target.value)}/><button type="button" className="btn" style={{height:40,whiteSpace:'nowrap'}} onClick={()=>setBpRefresh(n=>n+1)}>↻ Refresh</button></div> : tab!=='cashbook' && activeHeaderSection!=='Bahikhata' && <input className="input dealerSearch" placeholder="Search chassis, bill, challan, model…" value={search} onChange={e=>setSearch(e.target.value)}/>}
        </div>
        {tab==='cashbook' && canCashBook && <DealerCashBook/>}
        {tab==='all-expenses' && canCashBook && <DealerAllExpenses dealer={dealer}/>}
        {tab==='incentive' && canCashBook && <DealerIncentiveRegister dealer={dealer}/>}
        {tab==='receipt-create' && canCashBook && <DealerCashReceiptPage dealer={dealer}/>}
        {tab==='repair-receipt' && canRepairReceipt && <DealerRepairReceiptPage dealer={dealer}/>}
        {tab==='purchases' && canPurchase && <DealerTable headers={['Date','Challan No.','Product','Chassis No.','Action']} rows={filteredChallans} row={v=>{
          const invoiced=invoices.some(i=>i.chassis_no&&i.chassis_no===v.chassis_no);
          return <><td>{formatDate(v.date)}</td><td><b>{v.challan_no}</b></td><td>{v.product_name||'—'}</td><td>{v.chassis_no||'—'}</td>
            <td>{invoiced?<span className="muted">Invoiced</span>:<button className="btn primary" onClick={()=>{setSelectedPurchase(v);setTab('customer-invoice')}}>Create Invoice</button>}</td></>}}/>}
        {tab==='payments' && <DealerPaymentPage dealer={dealer}/>}
        {tab==='pending-sales' && canPendingFlow && <DealerPendingSalesPage/>}
        {tab==='balance-pending' && canPendingFlow && <DealerBalancePending search={bpSearch} refreshKey={bpRefresh}/>}
        {tab==='stock' && <><style>{`
          .sxChev{display:none}
          @media(max-width:700px){
            .dealerStockExpand .table tbody tr.sxRow{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:12px;row-gap:3px;padding:12px 14px;cursor:pointer}
            .dealerStockExpand .table tbody tr.sxRow.open{border-color:var(--accent)}
            .dealerStockExpand .table tbody tr.sxRow td:before{display:none}
            .dealerStockExpand .table tbody tr.sxRow td.sxKeep{display:block;border:0;padding:0;min-width:0;overflow-wrap:anywhere}
            .dealerStockExpand .table tbody tr.sxRow td.sxDate{grid-area:1/1;text-align:left;font-size:12px;color:var(--muted)}
            .dealerStockExpand .table tbody tr.sxRow td.sxChallan{grid-area:1/2;text-align:right;font-size:12px;color:var(--muted)}
            .dealerStockExpand .table tbody tr.sxRow td.sxModel{grid-area:2/1;text-align:left;font-size:13px;font-weight:600}
            .dealerStockExpand .table tbody tr.sxRow td.sxChassis{grid-area:2/2;text-align:right;font-size:13px}
            .dealerStockExpand .sxChev{display:inline-block;margin-left:8px;font-size:11px;color:var(--muted);transition:transform .15s}
            .dealerStockExpand tr.open .sxChev{transform:rotate(180deg)}
            .dealerStockExpand .table tbody tr.sxRow td.sxMore{display:none}
            .dealerStockExpand .table tbody tr.sxRow.open td.sxMore{display:flex;grid-column:1/-1;border-bottom:0;border-top:1px solid var(--line);padding:9px 0}
            .dealerStockExpand .table tbody tr.sxRow.open td.sxMore:first-of-type{margin-top:6px}
            .dealerStockExpand .table tbody tr.sxRow.open td.sxMore:before{display:block}
          }
        `}</style><DealerTable wrapClass="dealerStockExpand" headers={canCreateSale?['Date','Challan No.','Chassis No.','Model','Battery Make','Colour','Action']:['Date','Challan No.','Chassis No.','Model','Battery Make','Colour']} rows={filteredStock} pageSize={35} rowProps={v=>({className:'sxRow'+(openStock[v.id??v.chassis_no]?' open':''),'aria-expanded':!!openStock[v.id??v.chassis_no],onClick:()=>setOpenStock(m=>({...m,[v.id??v.chassis_no]:!m[v.id??v.chassis_no]}))})} row={v=><><td className="sxKeep sxDate" data-label="Date">{formatDate(v.date)}</td><td className="sxKeep sxChallan" data-label="Challan No.">{v.challan_no||'—'}</td><td className="sxKeep sxChassis" data-label="Chassis No."><b>{v.chassis_no}</b><span className="sxChev">▾</span></td><td className="sxKeep sxModel" data-label="Model">{v.model_name}</td><td className="sxMore" data-label="Battery Make">{v.battery_maker||'—'}</td><td className="sxMore" data-label="Colour">{v.colour}</td>{canCreateSale&&<td className="sxMore" data-label="Action"><button type="button" className="btn primary" onClick={e=>{e.stopPropagation();startSaleFromStock({kind:'new',chassis_no:v.chassis_no})}}>Create Sale</button></td>}</>}/></>}
{tab==='old-stock' && canPendingFlow && <div className="dealerOldStockPage"><div className="dealerOldStockHead"><div><div className="dealerOldStockKicker">STOCK</div><h2>Old Rickshaw Stock</h2><p>Factory challan se dealer ko receive hue Old Rickshaw yahan dikhte hain.</p></div><button type="button" className="btn" onClick={()=>get('/dealer/old-rickshaws').then(setOldStock).catch(e=>setError(e.message))}>↻ Refresh</button></div>{oldSaleNotice&&<div className="muted" style={{margin:'0 0 10px',color:'#15803d',fontWeight:700}}>{oldSaleNotice}</div>}<div className="dealerOldStockGrid"><div className="dealerOldStockStat"><span>Unsold Stock</span><b>{unsoldOldStock.length}</b></div><div className="dealerOldStockStat"><span>Available</span><b>{unsoldOldStock.filter(v=>!v.pending_sale_id).length}</b></div><div className="dealerOldStockStat"><span>Pending Sale</span><b>{unsoldOldStock.filter(v=>v.pending_sale_id).length}</b></div></div><div className="card dealerOldStockCard"><div className="tablewrap dealerTable dealerOldStockTableWrap"><table className="table dealerOldStockTable"><thead><tr><th>Date</th><th>Vehicle No.</th><th>Model</th><th>Owner / Customer</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>{unsoldOldStock.map(v=><tr key={v.id}><td data-label="Date">{formatDate(v.date||v.sale_date)}</td><td data-label="Vehicle No."><b>{v.vehicle_reg_no||'—'}</b></td><td data-label="Model">{v.model_name||'—'}</td><td data-label="Owner / Customer">{v.owner_name||v.sold_to||'—'}</td><td data-label="Amount">{v.sale_amount?'₹ '+Number(v.sale_amount).toLocaleString('en-IN'):'—'}</td><td data-label="Status"><span className={'dealerOldStockStatus '+(String(v.status||'').toLowerCase()==='sold'?'sold':'available')}>{v.pending_sale_id?'PENDING SALE':String(v.status||'available').toUpperCase()}</span></td><td data-label="Action">{canOldRickshawSales&&!v.pending_sale_id?<button type="button" className="btn primary" onClick={()=>{setOldSaleNotice('');setOldSaleRow(v)}}>Create Sale</button>:<span className="muted">—</span>}</td></tr>)}{!unsoldOldStock.length&&<tr><td colSpan="7"><div className="dealerEmpty">No Old Rickshaw in stock.</div></td></tr>}</tbody></table></div></div>{oldSaleRow&&<OldRickshawSaleModal manual={isUnregistered} row={oldSaleRow} onClose={()=>setOldSaleRow(null)} onDone={(msg)=>{setOldSaleRow(null);setOldSaleNotice(msg);get('/dealer/old-rickshaws').then(setOldStock).catch(()=>{})}}/>}</div>}
        {tab==='battery-stock' && <DealerTable headers={canCreateSale?['Date','Battery Maker','Battery No.','Reference','Action']:['Date','Battery Maker','Battery No.','Reference']} rows={filteredBatteryStock} pageSize={35} row={v=><><td data-label="Date">{formatDate(v.date)}</td><td data-label="Battery Maker">{v.battery_maker||'—'}</td><td data-label="Battery No."><b>{v.battery_no}</b></td><td data-label="Reference">{v.reference_no||'—'}</td>{canCreateSale&&<td data-label="Action"><button type="button" className="btn primary" onClick={()=>startSaleFromStock({kind:'battery',battery_no:String(v.battery_no||'').trim()})}>Create Sale</button></td>}</>}/>}
        {tab==='challans' && <DealerTable headers={['Date','Challan No.','Chassis No.','Model','Destination']} rows={filteredChallans} pageSize={35} row={c=><><td data-label="Date">{formatDate(c.date)}</td><td data-label="Challan No.">{c.challan_no}</td><td data-label="Chassis No.">{c.chassis_no}</td><td data-label="Model">{c.product_name}</td><td data-label="Destination">{c.destination}</td></>}/>}
        {tab==='all-receipt' && <DealerAllReceiptsPage dealer={dealer} canCreate={canCashBook} />}
        {tab==='all-customers' && <DealerAllCustomersPage />}
        {tab==='handover-create' && <DealerHandoverCreatePage />}
        {!['cashbook','receipt-create','repair-receipt','expenses-create','handover-create','cash-handover','all-receipt','all-customers','purchases','payments','ledger','pending-sales','balance-pending','stock','old-stock','battery-stock','challans','invoices','loan-status','seized-vehicles'].includes(tab) && tab!=='dashboard' && <div className="dealerPanel"><div className="dealerPanelHead"><div><h3>{dealerHeaderSections.flatMap(s=>s.items).find(x=>x[0]===tab)?.[1] || 'Dealer Module'}</h3><p>This module is available from the top header.</p></div></div><div className="dealerEmpty">Module screen ready — records will appear here.</div></div>}
        {tab==='seized-vehicles' && <div className="dealerPage"><div className="dealerPanel" style={{marginBottom:14}}><div className="dealerPanelHead"><div><h3>Seized Vehicles</h3><p>Vehicles physically parked at your dealer. CHFPL will release them for sale when applicable.</p></div><span className="pill d">HOLD</span></div>{!seizedVehicles.length?<div className="dealerEmpty">No seized vehicles are currently parked at this dealer.</div>:<div className="tablewrap dealerTable"><table className="table"><thead><tr><th>Repo Date</th><th>Loan</th><th>Vehicle</th><th>Model</th><th>Colour</th><th>Battery</th><th>RC</th><th>Charger</th><th>Status</th></tr></thead><tbody>{seizedVehicles.map(v=>{const loan=v.loan_applications||{};const customer=loan.customer_profiles||{};return <tr key={v.id}><td>{formatDate(v.repo_date)}</td><td><b>{loan.loan_account_no||loan.application_no||'—'}</b><div className="muted">{customer.full_name||'—'}</div></td><td><b>{v.vehicle_no||'—'}</b></td><td>{v.model_name||loan.grd_model_name||'—'}</td><td>{v.colour||'—'}</td><td>{v.battery_available?v.battery_no||'Yes':'No'}</td><td>{v.rc_available?'Yes':'No'}</td><td>{v.charger_available?'Yes':'No'}</td><td><span className="pill d">HOLD</span></td></tr>})}</tbody></table></div>}</div></div>}
      </>}
      </>}
    </main>
    <ChatWidget open={chatOpen} onOpenChange={setChatOpen} />
  </div>);
}

function DealerDashboard({dealerName,stockCount,challanCount,invoiceCount,loanCount,latest,onNewLoan,onOpen,canCashBook,canCreateSale,cashPos}) {
  const cash = cashPos ? '₹ '+Number(cashPos.cash_at_dealer||0).toLocaleString('en-IN',{maximumFractionDigits:2}) : '—';
  const actions = [
    {icon:'＋', label:'New Loan', onClick:onNewLoan, show:true},
    {icon:'🛻', label:'Create Sale', onClick:()=>onOpen('create-sale'), show:!!canCreateSale},
    {icon:'🧾', label:'Create Receipt', onClick:()=>onOpen('receipt-create'), show:!!canCashBook},
    {icon:'💸', label:'Shop Expense', onClick:()=>onOpen('expenses-create'), show:!!canCashBook},
  ].filter(a=>a.show);
  const stats = [
    ...(canCashBook ? [{key:'cashbook', icon:'💰', label:'Cash in Hand', value:cash, hero:true}] : []),
    {key:'stock', icon:'📦', label:'New Stock', value:stockCount ?? 0},
    {key:'challans', icon:'🚚', label:'Delivery Challans', value:challanCount ?? 0},
    {key:'invoices', icon:'🧾', label:'Tax Invoices', value:invoiceCount ?? 0},
    {key:'loan-status', icon:'🏦', label:'Loan Applications', value:loanCount ?? 0},
  ];
  return <div className="dealerPage dbx">
    <style>{`
      .dbx{display:grid;gap:16px}
      .dbxHello{display:flex;align-items:center;gap:12px}
      .dbxAvatar{width:44px;height:44px;flex:none;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#fff;font-weight:800;font-size:18px}
      .dbxHello h2{margin:0;font-size:20px;line-height:1.2;color:var(--ink);overflow-wrap:anywhere}
      .dbxHello p{margin:2px 0 0;font-size:12px;color:var(--muted)}
      .dbxActions{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
      .dbxAct{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:78px;padding:10px 6px;border-radius:14px;border:1px solid var(--accent);background:var(--accent);color:#fff;font-weight:700;font-size:13px;text-align:center;cursor:pointer;line-height:1.2}
      .dbxAct i{font-style:normal;font-size:22px;line-height:1}
      .dbxAct:active{transform:scale(.97)}
      .dbxStats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
      .dbxStat{display:flex;flex-direction:column;gap:6px;align-items:flex-start;text-align:left;padding:14px;border-radius:14px;border:1px solid var(--line);background:var(--card);color:var(--ink);cursor:pointer;min-width:0}
      .dbxStat:hover{border-color:var(--accent)}
      .dbxStat .ic{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;font-size:17px;background:color-mix(in srgb,var(--accent) 13%,transparent)}
      .dbxStat span.l{font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.3px}
      .dbxStat b{font-size:24px;line-height:1.1;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
      .dbxStat.hero{background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 65%,#000));border-color:transparent;color:#fff}
      .dbxStat.hero .ic{background:#ffffff26}.dbxStat.hero span.l{color:#ffffffcc}
      .dbxActions .dbxMob{display:none}
      .dbxStat .t{display:flex;flex-direction:column;gap:2px;min-width:0}
      .dbxFeed{border:1px solid var(--line);border-radius:14px;background:var(--card);overflow:hidden}
      .dbxFeedHead{padding:14px 16px;border-bottom:1px solid var(--line)}
      .dbxFeedHead h3{margin:0;font-size:16px;color:var(--ink)}.dbxFeedHead p{margin:2px 0 0;font-size:12px;color:var(--muted)}
      .dbxItem{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:2px 12px;align-items:center;padding:11px 16px;border-bottom:1px solid var(--line)}
      .dbxItem:last-child{border-bottom:0}
      .dbxItem .ty{grid-row:1/3;width:36px;height:36px;border-radius:10px;display:grid;place-items:center;font-size:17px;background:color-mix(in srgb,var(--accent) 13%,transparent)}
      .dbxItem .no{font-weight:800;font-size:14px;color:var(--ink);min-width:0;overflow-wrap:anywhere}
      .dbxItem .dt{font-size:12px;color:var(--muted);text-align:right;white-space:nowrap}
      .dbxItem .rf{grid-column:2/4;font-size:12px;color:var(--muted);min-width:0;overflow-wrap:anywhere}
      .dbxEmpty{padding:24px 16px;text-align:center;color:var(--muted);font-size:13px}
      @media(max-width:1000px){.dbxStats{grid-template-columns:repeat(3,minmax(0,1fr))}}
      @media(max-width:700px){
        .dbxActions{grid-template-columns:1fr 1fr}
        .dbxActions .dbxMob{display:flex}
        .dbxAct{flex-direction:row;justify-content:flex-start;gap:10px;min-height:54px;padding:10px 14px;font-size:14px;text-align:left}
        .dbxAct i{font-size:20px}
        .dbxStats{grid-template-columns:1fr 1fr;gap:8px}
        .dbxStat{padding:12px}.dbxStat b{font-size:20px}
        .dbxStat.hero{grid-column:1/-1;flex-direction:row;align-items:center;gap:12px}
        .dbxStat.hero .t{display:flex;flex-direction:column;gap:2px}
        .dbxStat.hero b{font-size:26px}
        .dbxItem{padding:10px 12px}
      }
    `}</style>

    <div className="dbxHello">
      <div className="dbxAvatar">{String(dealerName||'D').trim().charAt(0).toUpperCase()}</div>
      <div><h2>Welcome, {dealerName}</h2><p>Dealer dashboard and recent activity</p></div>
    </div>

    <div className="dbxActions">
      {actions.map(a=><button key={a.label} type="button" className="dbxAct" onClick={a.onClick}><i>{a.icon}</i><span>{a.label}</span></button>)}
      <button type="button" className="dbxAct dbxMob" onClick={()=>onOpen('all-customers')}><i>👥</i><span>All Customers</span></button>
      <button type="button" className="dbxAct dbxMob" onClick={()=>onOpen('all-receipt')}><i>🧾</i><span>All Receipt</span></button>
    </div>

    <div className="dbxStats">
      {stats.map(c=><button key={c.key} type="button" className={'dbxStat'+(c.hero?' hero':'')} onClick={()=>onOpen(c.key)}>
        <span className="ic">{c.icon}</span>
        <span className="t"><span className="l">{c.label}</span><b>{c.value}</b></span>
      </button>)}
    </div>

    <div className="dbxFeed">
      <div className="dbxFeedHead"><h3>Recent Activity</h3><p>Latest delivery challans and tax invoices</p></div>
      {latest?.length ? latest.map((x,i)=><div className="dbxItem" key={(x.type||'')+'-'+(x.no||'')+'-'+i}>
        <span className="ty">{/invoice/i.test(x.type||'')?'🧾':'🚚'}</span>
        <span className="no">{x.no||'—'}</span>
        <span className="dt">{formatDate(x.date)}</span>
        <span className="rf">{[x.type,x.text].filter(Boolean).join(' · ')||'—'}</span>
      </div>) : <div className="dbxEmpty">No recent activity.</div>}
    </div>
  </div>;
}

function DealerTable({headers,rows,row,pageSize=35,rowProps,wrapClass=''}) {
  const [page,setPage]=useState(1);
  const totalPages=Math.max(1,Math.ceil((rows?.length||0)/pageSize));
  const current=Math.min(page,totalPages);
  useEffect(()=>{if(page>totalPages)setPage(totalPages)},[page,totalPages]);
  const visible=(rows||[]).slice((current-1)*pageSize,current*pageSize);
  return <div className="card">
    <div className={"tablewrap dealerTable"+(wrapClass?" "+wrapClass:"")}><table className="table"><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead>
      <tbody>{visible.map((v,i)=><tr key={v?.id ?? v?.chassis_no ?? v?.challan_no ?? v?.bill_no ?? i} {...(rowProps?rowProps(v):{})}>{row(v)}</tr>)}
      {!visible.length && <tr><td colSpan={headers.length}><div className="dealerEmpty">No records found.</div></td></tr>}</tbody>
    </table></div>
    {totalPages>1 && <div className="dealerTablePager"><button type="button" className="btn" disabled={current<=1} onClick={()=>setPage(p=>Math.max(1,p-1))}>Previous</button><span>Page {current} / {totalPages}</span><button type="button" className="btn" disabled={current>=totalPages} onClick={()=>setPage(p=>Math.min(totalPages,p+1))}>Next</button></div>}
  </div>;
}

function DealerLoanStatusTable({rows,onRefresh,title='Loan Status',description='Dealer loan applications and their current status.',empty='No loan applications found.'}) {
  return <div className="dealerPage"><div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>{title}</h3><p>{description}</p></div><button type="button" className="btn" onClick={onRefresh}>↻ Refresh</button></div>
    {!rows?.length ? <div className="dealerEmpty">{empty}</div> :
      <div className="tablewrap dealerTable"><table className="table"><thead><tr><th>Application</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead><tbody>
        {rows.map((r,i)=><tr key={r.id ?? r.application_no ?? i}><td data-label="Application"><b>{r.application_no||r.loan_account_no||'—'}</b></td><td data-label="Customer">{r.customer_name||r.name||'—'}</td><td data-label="Amount">{r.loan_amount!=null ? '₹ '+Number(r.loan_amount).toLocaleString('en-IN') : '—'}</td><td data-label="Status">{String(r.status||'—').replaceAll('_',' ')}</td></tr>)}
      </tbody></table></div>}
  </div></div>;
}
function DealerLoanStatus({tab,rows,onRefresh}) {
  // Loan Status (upar red strip): All / Pending / Approved / Billed.
  // Approved = approved loans jinki sale/bill abhi banni hai (pehle ka "Pending Sales" page yahin hai).
  const st=(r)=>String(r.status||'').trim().toLowerCase();
  const isApproved=(r)=>st(r)==='approved';
  const isBilled=(r)=>st(r)==='disbursed'||st(r)==='billed';
  if(tab==='loan-approved') return <div className="dealerPage"><DealerPendingSalesPage/></div>;
  if(tab==='loan-pending') return <DealerLoanStatusTable rows={(rows||[]).filter(r=>!isApproved(r)&&!isBilled(r))} onRefresh={onRefresh} title="Pending Loans" description="Jin loans ka process abhi chal raha hai." empty="Koi pending loan nahi hai."/>;
  if(tab==='loan-billed') return <DealerLoanStatusTable rows={(rows||[]).filter(isBilled)} onRefresh={onRefresh} title="Billed Loans" description="Bill ban chuke / disbursed loans." empty="Koi billed loan nahi hai."/>;
  return <DealerLoanStatusTable rows={rows} onRefresh={onRefresh} title="All Loans" description="Dealer loan applications and their current status."/>;
}

function BatteryAdjustmentShell({title,description,onBack,children}) {
  return <div className="dealerPage">
    <div className="dealerPanel">
      <div className="dealerPanelHead"><div><h3>{title}</h3><p>{description}</p></div><button type="button" className="btn" onClick={onBack}>Back</button></div>
      {children}
    </div>
  </div>;
}

function DealerBatteryWithdrawal({dealer,onBack}) {
  const [form,setForm]=useState({date:new Date().toISOString().slice(0,10),battery_maker:'',battery_no:'',reference_no:''});
  const [saving,setSaving]=useState(false), [error,setError]=useState(''), [message,setMessage]=useState('');
  const [fitted,setFitted]=useState([]), [pick,setPick]=useState('');
  const loadFitted=()=>Promise.all([get('/dealer/rickshaw-battery-options?type=new'),get('/dealer/rickshaw-battery-options?type=old')]).then(([n,o])=>{
    const out=[];
    [['new',n.rickshaws],['old',o.rickshaws]].forEach(([t,list])=>(list||[]).forEach(r=>(r.battery_numbers||[]).forEach(no=>out.push({value:t+'|'+r.id+'|'+no,no,maker:r.battery_maker||'',label:[no,r.battery_maker,r.reg_no||r.chassis_no,r.model_name].filter(Boolean).join(' · ')}))));
    setFitted(out);
  }).catch(()=>{});
  useEffect(()=>{loadFitted()},[]);
  const pickFitted=(v)=>{setPick(v);const f=fitted.find(x=>x.value===v);if(f)setForm(x=>({...x,battery_no:f.no,battery_maker:f.maker||x.battery_maker}));};
  const submit=async(e)=>{e.preventDefault();setSaving(true);setError('');setMessage('');try{const res=await post('/battery-withdrawal',form);setMessage(res?.removed_from_rickshaw?'Battery removed from rickshaw and added back to stock.':'Battery stock added successfully.');setForm({...form,battery_no:'',reference_no:''});setPick('');loadFitted();}catch(err){setError(err.message||'Could not save withdrawal.')}finally{setSaving(false);}};
  return <BatteryAdjustmentShell title="Battery Withdrawal" description="Withdraw a battery (from a rickshaw or received) back into this dealer's battery stock. If it is fitted on your rickshaw it is removed from there." onBack={onBack}>
    <form onSubmit={submit} className="formgrid" style={{padding:16}}>
      <Field label="Date" type="date" value={form.date} onChange={v=>setForm({...form,date:v})}/>
      <Field label="Rickshaw par lagi Battery (dropdown)" type="select" value={pick} options={fitted.map(f=>({value:f.value,label:f.label}))} onChange={pickFitted}/>
      <div className="muted" style={{gridColumn:'1/-1',fontSize:12,marginTop:-6}}>Rickshaw se nikalni hai to yahan se chuno — Battery No. aur Maker apne aap bhar jayenge. Bahar se aayi (received) battery ke liye "Select..." rehne do aur neeche khud likho.</div>
      <Field label="Battery Maker" value={form.battery_maker} onChange={v=>setForm({...form,battery_maker:v})}/>
      <Field label="Battery No." value={form.battery_no} onChange={v=>{setPick('');setForm({...form,battery_no:v})}} required/>
      <Field label="Reference No." value={form.reference_no} onChange={v=>setForm({...form,reference_no:v})}/>
      {error&&<div style={{gridColumn:'1/-1'}}><ErrorBanner message={error}/></div>}
      {message&&<div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(34,160,90,.16)',color:'var(--ink,#147a42)'}}>{message}</div>}
      <div className="actions" style={{gridColumn:'1/-1'}}><button className="btn primary" disabled={saving}>{saving?'Saving…':'Save Withdrawal'}</button></div>
    </form>
  </BatteryAdjustmentShell>;
}

function DealerBatteryAddition({dealer,onBack}) {
  const [data,setData]=useState({batteries:[],vehicles:[]}),[form,setForm]=useState({date:new Date().toISOString().slice(0,10),source:'dealer',battery_no:'',battery_maker:'',vehicle_id:'',position:1,reference_no:''});
  const [makers,setMakers]=useState([]);
  const [saving,setSaving]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
  const load=()=>get('/dealer/battery-adjustment').then(setData).catch(e=>setError(e.message||'Could not load battery stock.'));
  useEffect(()=>{load();get('/masters/battery-maker').then(d=>{const rows=Array.isArray(d)?d:(d?.masters||d?.rows||d?.data||[]);setMakers(rows.map(x=>typeof x==='string'?x:(x.name||x.maker||x.battery_maker||'')).filter(Boolean))}).catch(()=>{})},[]);
  // Sirf wahi rickshaw jisme abhi koi battery nahi lagi.
  const freeVehicles=(data.vehicles||[]).filter(v=>![v.battery_no1,v.battery_no2,v.battery_no3,v.battery_no4].some(x=>String(x||'').trim()));
  const fromFactory=false; // Dealer login: battery hamesha apne stock se hi lagti hai (Source option hata diya)
  const selected=data.batteries.find(x=>String(x.battery_no)===String(form.battery_no));
  const makerOptions=[...new Set([...makers,...data.batteries.map(x=>String(x.battery_maker||'').trim()).filter(Boolean)])];
  const setSource=v=>setForm({...form,source:v,battery_no:'',battery_maker:''});
  const submit=async(e)=>{e.preventDefault();setSaving(true);setError('');setMessage('');
    try{
      if(fromFactory && !window.confirm('Ye battery FACTORY se aayi hai? Save karne par factory battery challan/register mein is dealer ki is rickshaw par entry ho jayegi.'))return;
      await post('/battery-addition',{...form,battery_maker:fromFactory?form.battery_maker:(selected?.battery_maker||'')});
      setMessage(fromFactory?'Factory battery fitted and challan updated successfully.':'Battery fitted to vehicle successfully.');
      setForm({...form,battery_no:'',reference_no:''});load();
    }catch(err){setError(err.message||'Could not fit battery.')}finally{setSaving(false);}};
  return <BatteryAdjustmentShell title="Battery Fitting" description="Fit a battery to a vehicle — from your dealer stock or directly from the factory." onBack={onBack}>
    <form onSubmit={submit} className="formgrid" style={{padding:16}}>
      <Field label="Date" type="date" value={form.date} onChange={v=>setForm({...form,date:v})}/>
      {data.batteries.length
        ? <Field label="Battery (apne stock se)" type="select" value={form.battery_no} options={[{value:'',label:'Select Battery'},...data.batteries.map(v=>({value:v.battery_no,label:[v.battery_no,v.battery_maker].filter(Boolean).join(' · ')}))]} onChange={v=>setForm({...form,battery_no:v,vehicle_id:v?form.vehicle_id:''})} required/>
        : <div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(214,150,20,.14)',fontSize:13}}>Aapke battery stock me abhi koi battery nahi hai.</div>}
      {form.battery_no&&(freeVehicles.length?<Field label="Vehicle (jisme lagani hai)" type="select" value={form.vehicle_id} options={[{value:'',label:'Select Vehicle'},...freeVehicles.map(v=>({value:v.id,label:[v.chassis_no,v.model_name].filter(Boolean).join(' · ')}))]} onChange={v=>setForm({...form,vehicle_id:v})} required/>:<div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(214,150,20,.14)',fontSize:13}}>Aapke stock me koi bina battery wali rickshaw nahi hai.</div>)}
      {form.battery_no&&<Field label="Battery Position" type="select" value={String(form.position)} options={[1,2,3,4].map(x=>({value:String(x),label:'Battery No. '+x}))} onChange={v=>setForm({...form,position:Number(v)})}/>}
      {form.battery_no&&<Field label="Reference No." value={form.reference_no} onChange={v=>setForm({...form,reference_no:v})}/>}
      {fromFactory&&<div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(214,150,20,.14)',fontSize:12}}>Factory battery: ye battery aapke dealer stock se nahi kategi. Save karne par battery challan / factory register mein "is dealer ko gayi, is rickshaw par lagi" ka record ban jayega.</div>}
      {error&&<div style={{gridColumn:'1/-1'}}><ErrorBanner message={error}/></div>}
      {message&&<div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(34,160,90,.16)',color:'var(--ink,#147a42)'}}>{message}</div>}
      <div className="actions" style={{gridColumn:'1/-1'}}><button className="btn primary" disabled={saving||!form.battery_no||!form.vehicle_id}>{saving?'Saving…':(fromFactory?'Fit Factory Battery':'Fit Battery')}</button></div>
    </form>
  </BatteryAdjustmentShell>;
}

function DealerBatterySwap({dealer,onBack}) {
  const [stock,setStock]=useState({new:[],old:[]}),[form,setForm]=useState({from_type:'new',from_id:'',to_type:'new',to_id:'',mode:'swap',date:new Date().toISOString().slice(0,10),remarks:''});
  const [saving,setSaving]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
  const load=()=>Promise.all([get('/dealer/rickshaw-battery-options?type=new'),get('/dealer/rickshaw-battery-options?type=old')]).then(([n,o])=>setStock({new:n.rickshaws||[],old:o.rickshaws||[]})).catch(e=>setError(e.message||'Could not load rickshaws.'));
  useEffect(()=>{load()},[]);
  const typeOptions=[{value:'new',label:'New Rickshaw'},{value:'old',label:'Old Rickshaw'}];
  const opts=(type,placeholder,skipType,skipId,need)=>[{value:'',label:placeholder},...(stock[type]||[]).filter(r=>!(type===skipType&&String(r.id)===String(skipId))&&(need==='has'?r.has_battery:need==='empty'?!r.has_battery:true)).map(r=>({value:r.id,label:[r.reg_no||r.chassis_no,r.model_name,r.has_battery?('Battery: '+(r.battery_maker||'—')+' | '+(r.battery_numbers||[]).join(', ')):'NO BATTERY'].filter(Boolean).join(' · ')}))];
  const submit=async(e)=>{e.preventDefault();setSaving(true);setError('');setMessage('');try{await post('/battery-swap-vouchers',{...form,from_id:Number(form.from_id),to_id:Number(form.to_id)});setMessage('Battery exchange completed successfully.');setForm({...form,from_id:'',to_id:'',remarks:''});load();}catch(err){setError(err.message||'Could not exchange batteries.')}finally{setSaving(false);}};
  const total=stock.new.length+stock.old.length;
  return <BatteryAdjustmentShell title="Battery Exchange" description="Exchange batteries between rickshaws in your stock: New ⇄ New, Old ⇄ Old, New ⇄ Old or Old ⇄ New." onBack={onBack}>
    <form onSubmit={submit} className="formgrid" style={{padding:16}}>
      <Field label="Date" type="date" value={form.date} onChange={v=>setForm({...form,date:v})}/>
      <Field label="Mode" type="select" value={form.mode} options={[{value:'swap',label:'Exchange / Swap — dono ki battery badlo'},{value:'transfer',label:'Transfer — ek se doosri me shift'}]} onChange={v=>setForm({...form,mode:v,to_id:''})}/>
      <div className="muted" style={{gridColumn:'1/-1',fontSize:12,marginTop:-6}}>{form.mode==='transfer'?'Transfer: Source rickshaw ki battery Target rickshaw me chali jati hai. Target me pehle se battery nahi honi chahiye; Source khali ho jata hai.':'Exchange / Swap: Source aur Target rickshaw ki batteries aapas me badal jati hain (Source ki battery Target me, Target ki Source me).'}</div>
      <Field label="From Rickshaw Type" type="select" value={form.from_type} options={typeOptions} onChange={v=>{setError('');setForm({...form,from_type:v,from_id:''})}}/>
      <Field label="Source Rickshaw" type="select" value={form.from_id} options={opts(form.from_type,'Select Source Rickshaw',null,null,'has')} onChange={v=>{setError('');setForm({...form,from_id:v})}} required/>
      <Field label="To Rickshaw Type" type="select" value={form.to_type} options={typeOptions} onChange={v=>{setError('');setForm({...form,to_type:v,to_id:''})}}/>
      <Field label="Target Rickshaw" type="select" value={form.to_id} options={opts(form.to_type,'Select Target Rickshaw',form.from_type,form.from_id,form.mode==='transfer'?'empty':'any')} onChange={v=>{setError('');setForm({...form,to_id:v})}} required/>
      <Field label="Remarks" value={form.remarks} onChange={v=>setForm({...form,remarks:v})}/>
      {error&&<div style={{gridColumn:'1/-1'}}><ErrorBanner message={error}/></div>}
      {message&&<div style={{gridColumn:'1/-1',padding:10,borderRadius:8,background:'rgba(34,160,90,.16)',color:'var(--ink,#147a42)'}}>{message}</div>}
      <div className="actions" style={{gridColumn:'1/-1'}}><button className="btn primary" disabled={saving||total<2}>{saving?'Saving…':'Exchange Battery'}</button></div>
    </form>
  </BatteryAdjustmentShell>;
}
function OldRickshawSaleModal({row,onClose,onDone,manual=false}) {
  // Old Rickshaw Stock se Create Sale. Sale pehle Pending Sales me jaati hai;
  // Billing approval ke baad gaadi Sold hoti hai aur sale data CHFPL ko jata hai.
  const todayStr=()=>new Date().toISOString().slice(0,10);
  const [form,setForm]=useState({sale_date:todayStr(),customer_id:'',customer_name:'',customer_mobile:'',amount_received:'',sale_amount:'',loan_amount:'0',do_number:''});
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  const [customers,setCustomers]=useState([]);
  // Booking customers (Create Sale wali list). Sirf Old Rickshaw booking wale customers dropdown me aate hain.
  useEffect(()=>{
    (async()=>{
      try{
        const c=await get('/billing/pending-sales/options?part=customers',{noClientCache:true,timeoutMs:30000});
        setCustomers((c.cash_customers||[]).filter(x=>String(x.booking_for||x.vehicle_no||'').trim().toLowerCase()==='old'));
      }catch(e){setError(e.message||'Could not load customers')}
    })();
  },[]);
  const pickCustomer=(id)=>{
    const c=customers.find(x=>String(x.id)===String(id));
    setForm(x=>({...x,customer_id:id,customer_name:c?.name||'',
      sale_amount:c?String(Number(c.sale_amount||0)||''):'',loan_amount:c?String(Number(c.loan_amount||0)||0):'0'}));
  };
  const selCust=customers.find(x=>String(x.id)===String(form.customer_id));
  const paidAmt=Number(selCust?.paid_amount||0);
  const custLabel=c=>[c.page_no?('Page: '+c.page_no):'',c.name,c.phone].filter(Boolean).join(' · ');
  const setF=(k,v)=>setForm(x=>({...x,[k]:v}));
  const balance=Math.max(0,Number(form.sale_amount||0)-Number(form.loan_amount||0)-paidAmt);
  const save=async(e)=>{
    e.preventDefault();
    if(manual){if(!String(form.customer_name||'').trim()){setError('Customer Name bharo.');return}}
    else if(!selCust){setError('Customer select karo.');return}
    setBusy(true);setError('');
    try{
      await post('/billing/pending-sales/create',{
        sale_category:'OLD',old_rickshaw_id:row.id,sp_no:row.sp_no||'',sale_date:form.sale_date,
        ...(manual?{}:{dealer_cash_customer_id:Number(selCust.id)}),customer_name:manual?form.customer_name.trim():(selCust.name||form.customer_name),buyer_name:manual?form.customer_name.trim():(selCust.name||form.customer_name),
        buyer_mobile:manual?form.customer_mobile:(selCust.phone||''),customer_phone:manual?form.customer_mobile:(selCust.phone||''),dealer_page_no:manual?'':(selCust.page_no||''),
        sale_amount:Number(form.sale_amount||0),loan_amount:Number(form.loan_amount||0),hypothecation_amount:Number(form.loan_amount||0),
        amount_received:manual?Number(form.amount_received||0):paidAmt,do_no:form.do_number||'',ledger_no:''
      },{timeoutMs:60000});
      onDone('Sale Pending Sales me bhej di gayi: '+(row.vehicle_reg_no||'Old Rickshaw')+' → '+form.customer_name+'. Approval ke baad Sold hogi.');
    }catch(err){setError(err.message||'Could not create Old Rickshaw sale.')}
    finally{setBusy(false)}
  };
  return <div className="modal"><form className="modalbox" onSubmit={save}>
    <h2>Create Old Rickshaw Sale</h2>
    {error&&<ErrorBanner message={error}/>}
    <div className="muted" style={{marginBottom:8}}>Sale pehle Pending Sales me jayegi. Approval ke baad hi Sold hogi.</div>
    <div className="formgrid">
      <Field label="SP No." value={row.sp_no||'—'} readOnly/>
      <Field label="Sale Date" type="date" value={form.sale_date} onChange={v=>setF('sale_date',v)} required/>
      {manual ? <>
        <Field label="Customer Name" value={form.customer_name} onChange={v=>setF('customer_name',v)} required/>
        <Field label="Customer Mobile" value={form.customer_mobile} onChange={v=>setF('customer_mobile',String(v||'').replace(/\D/g,'').slice(0,10))}/>
        <Field label="Sale Amount" type="number" value={form.sale_amount} onChange={v=>setF('sale_amount',v)} required/>
        <Field label="Loan Amount (finance ho to)" type="number" value={form.loan_amount} onChange={v=>setF('loan_amount',v)}/>
        <Field label="Amount Received" type="number" value={form.amount_received} onChange={v=>setF('amount_received',v)}/>
        <Field label="Balance" type="number" value={Math.max(0,Number(form.sale_amount||0)-Number(form.loan_amount||0)-Number(form.amount_received||0))} readOnly/>
      </> : <>
      <label className="field"><span>Customer (booking)</span>
        <select className="input" value={form.customer_id||''} onChange={e=>pickCustomer(e.target.value)} required>
          <option value="">{customers.length?'Select Customer':'Koi Old Rickshaw booking customer nahi hai'}</option>
          {customers.map(c=><option key={c.id} value={c.id}>{custLabel(c)}</option>)}
        </select>
      </label>
      <Field label="Sale Amount" type="number" value={form.sale_amount} readOnly/>
        <Field label="Loan Amount" type="number" value={form.loan_amount} onChange={v=>setF("loan_amount",v)}/>
      <Field label="Amount Received (booking)" type="number" value={paidAmt} readOnly/>
      <Field label="Balance" type="number" value={balance} readOnly/>
      </>}
      <Field label="DO No. (Optional)" value={form.do_number} onChange={v=>setF('do_number',v)}/>
      <Field label="Vehicle No." value={row.vehicle_reg_no||'—'} readOnly/>
      <Field label="Model" value={row.model_name||'—'} readOnly/>
    </div>
    <div className="actions" style={{marginTop:18,justifyContent:'flex-end'}}>
      <button type="button" className="btn" onClick={onClose}>Cancel</button>
      <button className="btn primary" disabled={busy||(manual?!String(form.customer_name||'').trim():!selCust)||!(Number(form.sale_amount||0)>0)||Number(form.loan_amount||0)>Number(form.sale_amount||0)}>{busy?'Saving…':'Send to Pending'}</button>
    </div>
  </form></div>;
}
function DealerOldRickshawSold() {
  // All Sale > Old Rickshaw Sale: sirf becchi gayi (Sold) gaadiyan. Stock / Create Sale ab My Stock > Old Rickshaw Stock me hai.
  const [rows,setRows]=useState([]);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [search,setSearch]=useState('');
  const load=async()=>{
    try{setError('');const r=await get('/dealer/old-rickshaws',{noClientCache:true});setRows(r.rickshaws||[]);}
    catch(e){setError(e.message||'Could not load Old Rickshaw sales.')}
    finally{setLoading(false)}
  };
  useEffect(()=>{load()},[]);
  const q=search.trim().toLowerCase();
  const sold=rows.filter(v=>String(v.status||'').toLowerCase()==='sold'&&(!q||[v.vehicle_reg_no,v.model_name,v.challan_no,v.sp_no,v.customer_name,v.out_name,v.owner_name].join(' ').toLowerCase().includes(q)));
  const money=(n)=>n?'₹ '+Number(n).toLocaleString('en-IN'):'—';
  return <div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>Old Rickshaw Sale</h3><p>Aapke dwara becchi gayi gaadiyan.</p></div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}}><span className="pill t">{sold.length} Sold</span><input className="input dealerSearch" placeholder="Search vehicle / model…" value={search} onChange={e=>setSearch(e.target.value)}/><button type="button" className="btn" onClick={load}>↻ Refresh</button></div></div>
    {error&&<ErrorBanner message={error}/>}
    {loading?<div className="dealerEmpty">Loading…</div>:!sold.length?<div className="dealerEmpty">Abhi koi Old Rickshaw sale nahi hui.</div>:
    <div className="tablewrap dealerTable"><table className="table">
      <thead><tr><th>Sale Date</th><th>Vehicle No.</th><th>Model</th><th>Customer</th><th>Sale Amt.</th><th>Loan</th><th>Balance</th></tr></thead>
      <tbody>{sold.map(v=><tr key={v.id}>
        <td data-label="Sale Date">{formatDate(v.sale_date||v.date)}</td>
        <td data-label="Vehicle No."><b>{v.vehicle_reg_no||'—'}</b></td>
        <td data-label="Model">{v.model_name||'—'}</td>
        <td data-label="Customer">{v.customer_name||v.out_name||v.owner_name||'—'}</td>
        <td data-label="Sale Amt.">{money(v.sale_amount)}</td>
        <td data-label="Loan">{money(v.loan_amount)}</td>
        <td data-label="Balance">{money(v.balance_amount)}</td>
      </tr>)}</tbody>
    </table></div>}
  </div>;
}
function DealerBalancePending({search='',refreshKey=0}) {
  // Pending > Balance Pending: Billed customers jinka balance amount abhi baaki hai.
  // Search + Refresh page ke upar toolbar me hain. Mobile: list me sirf naam + balance, touch par poori detail.
  const [rows,setRows]=useState([]);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [open,setOpen]=useState({});
  const load=async()=>{
    try{setError('');const r=await get('/dealer/cash-book/customers?status=BILLED&payable_only=1',{noClientCache:true,timeoutMs:60000});setRows(r.customers||[]);}
    catch(e){setError(e.message||'Could not load balance pending customers.')}
    finally{setLoading(false)}
  };
  useEffect(()=>{load()},[refreshKey]);
  const q=search.trim().toLowerCase();
  const list=rows.filter(c=>Number(c.balance||0)>0&&(!q||[c.page_no,c.name,c.phone,c.vehicle_no].join(' ').toLowerCase().includes(q)));
  const total=list.reduce((t,c)=>t+Number(c.balance||0),0);
  const money=(n)=>'₹ '+Number(n||0).toLocaleString('en-IN');
  return <div className="dealerPage"><div className="dealerPanel">
    <style>{`
      .bpChev{display:none}
      @media(max-width:700px){
        .dealerBpTable .table tbody tr.bpRow{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:12px;align-items:center;padding:13px 14px;cursor:pointer}
        .dealerBpTable .table tbody tr.bpRow.open{border-color:var(--accent)}
        .dealerBpTable .table tbody tr.bpRow td:before{display:none}
        .dealerBpTable .table tbody tr.bpRow td.bpKeep{display:block;border:0;padding:0;min-width:0;overflow-wrap:anywhere}
        .dealerBpTable .table tbody tr.bpRow td.bpName{grid-area:1/1;text-align:left;font-size:14px}
        .dealerBpTable .table tbody tr.bpRow td.bpBal{grid-area:1/2;text-align:right;font-size:14px}
        .dealerBpTable .bpChev{display:inline-block;margin-left:8px;font-size:11px;color:var(--muted);transition:transform .15s}
        .dealerBpTable tr.open .bpChev{transform:rotate(180deg)}
        .dealerBpTable .table tbody tr.bpRow td.bpMore{display:none}
        .dealerBpTable .table tbody tr.bpRow.open td.bpMore{display:flex;grid-column:1/-1;border-bottom:0;border-top:1px solid var(--line);padding:9px 0}
        .dealerBpTable .table tbody tr.bpRow.open td.bpMore:first-of-type{margin-top:10px}
        .dealerBpTable .table tbody tr.bpRow.open td.bpMore:before{display:block}
        .dealerBpTable .table tfoot{display:none}
      }
    `}</style>
    {error&&<ErrorBanner message={error}/>}
    {!loading&&<div className="dealerDashboardStats" style={{marginBottom:12,gridTemplateColumns:'repeat(2,minmax(0,1fr))'}}>
      <div className="dealerDashStat" style={{cursor:'default'}}><span>Customers</span><b>{list.length}</b></div>
      <div className="dealerDashStat" style={{cursor:'default'}}><span>Total Balance Pending</span><b>{money(total)}</b></div>
    </div>}
    {loading?<div className="dealerEmpty">Loading…</div>:!list.length?<div className="dealerEmpty">Kisi Billed customer ka balance pending nahi hai.</div>:
    <div className="tablewrap dealerTable dealerBpTable"><table className="table">
      <thead><tr><th>Date</th><th>Page No.</th><th>Customer</th><th>Mobile</th><th>Vehicle No.</th><th>Sale Amt.</th><th>Loan</th><th>Received</th><th>Balance</th></tr></thead>
      <tbody>{list.map(c=><tr key={c.id} className={'bpRow'+(open[c.id]?' open':'')} aria-expanded={!!open[c.id]} onClick={()=>setOpen(m=>({...m,[c.id]:!m[c.id]}))}>
        <td className="bpMore" data-label="Date">{formatDate(c.date)}</td><td className="bpMore" data-label="Page No.">{c.page_no||'—'}</td><td className="bpKeep bpName" data-label="Customer"><b>{c.name||'—'}</b></td><td className="bpMore" data-label="Mobile">{c.phone||'—'}</td>
        <td className="bpMore" data-label="Vehicle No.">{c.vehicle_no||'—'}</td><td className="bpMore" data-label="Sale Amt.">{money(c.sale_amount)}</td><td className="bpMore" data-label="Loan">{money(c.loan_amount)}</td><td className="bpMore" data-label="Received">{money(c.paid_amount)}</td><td className="bpKeep bpBal" data-label="Balance"><b>{money(c.balance)}</b><span className="bpChev">▾</span></td>
      </tr>)}</tbody>
      <tfoot><tr><th colSpan="8">Total</th><th>{money(total)}</th></tr></tfoot>
    </table></div>}
  </div></div>;
}
function DealerDealerModulePlaceholder({title,description,onBack}) {
  return <div className="dealerPage"><div className="dealerPanel"><div className="dealerPanelHead"><div><h3>{title}</h3><p>{description}</p></div><button type="button" className="btn" onClick={onBack}>Back</button></div><div className="dealerEmpty">Module screen is ready.</div></div></div>;
}

function DealerCreateSaleForm({dealer,stock,oldStock,batteryStock,preset=null,onBack}) {
  // Showroom / Branch dealers create their own Pending Sale. It goes to Billing (Open for Approve) exactly like an admin-created one.
  // Dealer = logged-in dealer (auto). Sale type New / Old / Battery comes from the customer's booking.
  const [customers,setCustomers]=useState([]);
  const [vehicles,setVehicles]=useState([]);
  const [dealerName,setDealerName]=useState(dealer?.name||dealer?.dealer_name||'');
  const [customerId,setCustomerId]=useState('');
  const [item,setItem]=useState('');
  const [batteryQty,setBatteryQty]=useState('1');
  const [batteryNos,setBatteryNos]=useState([preset?.kind==='battery'?preset.battery_no:'']);
  const [saleAmount,setSaleAmount]=useState('');
  const [loanAmount,setLoanAmount]=useState('0');
  const [doNo,setDoNo]=useState('');
  const [ledgerNo,setLedgerNo]=useState('');
  const [remarks,setRemarks]=useState('');
  const [loading,setLoading]=useState(true);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');

  useEffect(()=>{
    (async()=>{
      try{
        const [d,v,c]=await Promise.all([
          get('/billing/pending-sales/options?part=dealers',{noClientCache:true,timeoutMs:30000}),
          get('/billing/pending-sales/options?part=vehicles',{noClientCache:true,timeoutMs:30000}),
          get('/billing/pending-sales/options?part=customers',{noClientCache:true,timeoutMs:30000})
        ]);
        setDealerName(d.dealers?.[0]?.name||dealerName);
        setVehicles(v.vehicles||[]);
        setCustomers(c.cash_customers||[]);
      }catch(e){setError(e.message||'Could not load customers / stock')}
      finally{setLoading(false)}
    })();
  },[]);

  const selectedCustomer=customers.find(c=>String(c.id)===String(customerId));
  const bookingTypeOf=c=>{const t=String(c?.booking_for||c?.vehicle_no||'').trim().toLowerCase();return ['new','old','battery'].includes(t)?t:''};
  // Opened from a My Stock row: the stock item is already fixed, so only customers whose booking matches that item type are offered.
  const type=preset?.kind||bookingTypeOf(selectedCustomer);
  const visibleCustomers=preset?customers.filter(c=>bookingTypeOf(c)===preset.kind):customers;
  const normCh=v=>String(v||'').trim().toUpperCase();
  const presetItem=preset?.kind==='new'?vehicles.find(v=>normCh(v.chassis_no)===normCh(preset.chassis_no))?.challan_id:null;
  useEffect(()=>{if(presetItem)setItem(String(presetItem))},[presetItem]);
  const typeLabel=type==='new'?'New Rickshaw':type==='old'?'Old Rickshaw':type==='battery'?'Battery':'—';

  const options=type==='new'
    ? vehicles.map(v=>({value:String(v.challan_id),label:[v.chassis_no,v.model_name||v.product_name,v.colour].filter(Boolean).join(' · ')||'New Rickshaw',raw:v}))
    : type==='old'
    ? (oldStock?.rickshaws||[]).filter(v=>String(v.status||'').toLowerCase()==='available'&&!v.pending_sale_id).map(v=>({value:String(v.id),label:[v.model_name,v.battery_maker,v.vehicle_reg_no].filter(Boolean).join(' · ')||'Old Rickshaw',raw:v}))
    : [];
  const selected=options.find(o=>o.value===String(item))?.raw;

  // Battery sale: Qty ke barabar battery-number select boxes, dealer ke battery stock se (duplicate number nahi).
  const stockBatteries=useMemo(()=>{
    const seen=new Set();
    return (batteryStock?.batteries||[]).filter(v=>{
      const no=String(v.battery_no||'').trim().toUpperCase();
      if(!no||seen.has(no))return false;
      seen.add(no);return true;
    });
  },[batteryStock]);
  const qtyNum=Math.max(1,Math.min(Number(batteryQty)||1,stockBatteries.length||1,50));
  const pickedBatteries=batteryNos.slice(0,qtyNum).map(no=>stockBatteries.find(b=>String(b.battery_no).trim()===String(no).trim())).filter(Boolean);
  const batteryReady=type==='battery'&&pickedBatteries.length===qtyNum;
  const changeBatteryQty=v=>{
    setBatteryQty(v);
    const n=Math.max(1,Math.min(Number(v)||1,stockBatteries.length||1,50));
    setBatteryNos(cur=>Array.from({length:n},(_,i)=>cur[i]||''));
  };
  const setBatteryNoAt=(i,v)=>setBatteryNos(cur=>{const nx=[...cur];nx[i]=v;return nx});

  useEffect(()=>{
    setItem(presetItem?String(presetItem):'');setBatteryQty('1');setBatteryNos([preset?.kind==='battery'?preset.battery_no:'']);
    if(!selectedCustomer){setSaleAmount('');setLoanAmount('0');setDoNo('');return}
    // Booking is the source of truth for amounts.
    setSaleAmount(String(Number(selectedCustomer.sale_amount||0)||''));
    setLoanAmount(String(Number(selectedCustomer.loan_amount||0)||0));
    setDoNo('');
  },[selectedCustomer?.id]);

  const paid=Number(selectedCustomer?.paid_amount||0);
  const balance=Math.max(0,Number(saleAmount||0)-Number(loanAmount||0)-paid);
  const customerLabel=c=>[c.page_no?('Page: '+c.page_no):'',c.name,c.phone,(c.booking_for||c.vehicle_no)?('Type: '+String(c.booking_for||c.vehicle_no).toUpperCase()):''].filter(Boolean).join(' · ');

  const save=async()=>{
    if(!selectedCustomer||!type||(type==='battery'?!batteryReady:!selected))return;
    setSaving(true);setError('');
    try{
      if(!(Number(saleAmount)>0))throw new Error('Booking me Sale Amount nahi hai. Pehle customer booking me Sale Amount bharo.');
      if(Number(loanAmount||0)>Number(saleAmount||0))throw new Error('Loan Amount Sale Amount se zyada nahi ho sakta.');
      let description,extra={};
      if(type==='new'){
        extra={vehicle_id:Number(selected.challan_id),delivery_challan_id:Number(selected.challan_id)};
        description='Internal Sale';
      }else if(type==='old'){
        description='Old Rickshaw · '+[selected.vehicle_reg_no,selected.model_name].filter(Boolean).join(' · ');
        extra={vehicle_id:null,delivery_challan_id:null,vehicle_reg_no:selected.vehicle_reg_no||'',old_rickshaw_id:Number(selected.id),sp_no:selected.sp_no||'',sale_date:new Date().toISOString().slice(0,10)};
      }else{
        const makers=[...new Set(pickedBatteries.map(b=>String(b.battery_maker||'').trim()).filter(Boolean))].join(' / ');
        description='Battery · '+[makers,'Qty '+qtyNum,pickedBatteries.map(b=>String(b.battery_no).trim()).join(', ')].filter(Boolean).join(' · ');
        extra={vehicle_id:null,delivery_challan_id:null};
      }
      await post('/billing/pending-sales/create',{
        sale_category:type.toUpperCase(),dealer_id:Number(dealer?.dealer_id||dealer?.id||0)||undefined,
        dealer_cash_customer_id:Number(selectedCustomer.id),
        buyer_name:selectedCustomer.name||'',customer_name:selectedCustomer.name||'',
        buyer_mobile:selectedCustomer.phone||'',customer_phone:selectedCustomer.phone||'',
        dealer_page_no:selectedCustomer.page_no||'',
        sale_amount:Number(saleAmount),loan_amount:Number(loanAmount||0),hypothecation_amount:Number(loanAmount||0),
        amount_received:paid,do_no:doNo.trim()||'',ledger_no:type==='old'?ledgerNo.trim():'',
        description,internal_sale_details:[description,remarks.trim()].filter(Boolean).join(' | '),
        ...extra
      },{timeoutMs:60000});
      alert('Sale Billing ko approval ke liye bhej di gayi hai.');
      onBack();
    }catch(e){setError(e.message||'Could not save sale')}
    finally{setSaving(false)}
  };

  return <div className="grdFormPage dealerCreateSalePage">
    <div className="dealerPanel dealerCreateSalePanel">
      <div className="dealerPanelHead">
        <div><h3>Create Sale</h3><p>Customer select karte hi booking ka Sale Type (New / Old / Battery) aur Sale Amount automatically aa jayenge. Save ke baad sale Billing approval me jaati hai.</p></div>
        <button type="button" className="btn" onClick={onBack}>Back</button>
      </div>

      {error&&<div className="error" style={{marginBottom:12}}>{error}</div>}
      {loading?<div className="dealerEmpty">Loading customers and stock…</div>:
      <div className="dealerCreateSaleGrid">
        {preset&&<div style={{gridColumn:'1 / -1',padding:'8px 12px',borderRadius:8,background:'rgba(56,189,248,.12)',fontSize:13}}>
          Stock se sale: <b>{preset.kind==='battery'?('Battery '+preset.battery_no):('Chassis '+preset.chassis_no)}</b> — ab sirf customer select karo.
          {preset.kind==='new'&&vehicles.length>0&&!presetItem&&<div style={{color:'#f87171',marginTop:4}}>Ye gaadi abhi Create Sale ke liye available nahi hai (pending sale ya bill ban chuka hai).</div>}
        </div>}
        <label>Customer (booking)
          <select className="input" value={customerId} onChange={e=>setCustomerId(e.target.value)}>
            <option value="">{visibleCustomers.length?'Select Customer':(preset?'Is item type ka koi booking customer nahi':'No Vehicle Pending Customer')}</option>
            {visibleCustomers.map(c=><option key={c.id} value={c.id}>{customerLabel(c)}</option>)}
          </select>
        </label>

        <label>Dealer Page No.
          <input className="input" value={selectedCustomer?.page_no||''} readOnly />
        </label>

        <label>Sale Type (booking se)
          <input className="input" value={typeLabel} readOnly />
        </label>

        {type==='battery' ? <>
          <label>Battery Qty
            <input className="input" type="number" min="1" max={stockBatteries.length||1} value={batteryQty} onChange={e=>changeBatteryQty(e.target.value)} readOnly={Boolean(preset)} />
            <small className="muted">Stock me available: {stockBatteries.length}</small>
          </label>
          {Array.from({length:qtyNum},(_,i)=>{
            const taken=new Set(batteryNos.slice(0,qtyNum).filter((x,j)=>j!==i&&x).map(x=>String(x).trim()));
            return <label key={i}>Battery No. {i+1}
              <select className="input" value={batteryNos[i]||''} onChange={e=>setBatteryNoAt(i,e.target.value)} disabled={Boolean(preset)}>
                <option value="">{stockBatteries.length?'Select Battery No.':'Stock me koi battery nahi hai'}</option>
                {stockBatteries.filter(b=>!taken.has(String(b.battery_no).trim())).map(b=><option key={b.battery_no} value={String(b.battery_no).trim()}>{[b.battery_no,b.battery_maker].filter(Boolean).join(' · ')}</option>)}
              </select>
            </label>;
          })}
        </> :         <label className="dealerCreateSaleItemField">Select {type?typeLabel:'Stock Item'}
          <select className="input" value={item} onChange={e=>setItem(e.target.value)} disabled={!type||Boolean(preset)}>
            <option value="">{!type?'Select customer first':options.length?'Select item':'Stock me koi item nahi hai'}</option>
            {options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>}

        <label>Sale Amount
          <input className="input" type="number" value={saleAmount} readOnly />
        </label>

        <label>Loan Amount
          <input className="input" type="number" min="0" max={saleAmount||undefined} value={loanAmount} onChange={e=>setLoanAmount(e.target.value)} disabled={!selectedCustomer} />
        </label>

        <label>Amount Received (booking)
          <input className="input" type="number" value={paid} readOnly />
        </label>

        <label>Balance
          <input className="input" type="number" value={balance} readOnly />
        </label>

        <label>DO No. (Optional)
          <input className="input" value={doNo} onChange={e=>setDoNo(e.target.value)} placeholder="Enter DO No. (optional)" />
        </label>

        {type==='old'&&<label>Ledger No. (Optional - approval par admin bharega)
          <input className="input" value={ledgerNo} onChange={e=>setLedgerNo(e.target.value)} placeholder="Enter Ledger No." disabled={!selectedCustomer} />
        </label>}

        <label>Remarks (Optional)
          <input className="input" value={remarks} onChange={e=>setRemarks(e.target.value)} />
        </label>
      </div>}

      {selectedCustomer && <div className="dealerCreateSalePreview">
        <div className="dealerCreateSalePreviewHead"><strong>Booking</strong><span>{typeLabel.toUpperCase()}</span></div>
        <div className="dealerCreateSalePreviewGrid">
          <div><span>Name</span><b>{selectedCustomer.name||'—'}</b></div>
          <div><span>Phone</span><b>{selectedCustomer.phone||'—'}</b></div>
          <div><span>Booking Paid</span><b>₹ {paid.toLocaleString('en-IN')}</b></div>
        </div>
      </div>}

      {(type==='battery'?batteryReady:selected) && <div className="dealerCreateSalePreview">
        <div className="dealerCreateSalePreviewHead"><strong>Vehicle</strong><span>{typeLabel}</span></div>
        <div className="dealerCreateSalePreviewGrid">
          {type==='new' && <>
            <div><span>Chassis</span><b>{selected.chassis_no||'—'}</b></div>
            <div><span>Model</span><b>{selected.model_name||selected.product_name||'—'}</b></div>
            <div><span>Colour</span><b>{selected.colour||'—'}</b></div>
          </>}
          {type==='old' && <>
            <div><span>Model</span><b>{selected.model_name||'—'}</b></div>
            <div><span>Battery Name</span><b>{selected.battery_name||selected.battery_maker||'—'}</b></div>
            <div><span>Vehicle No.</span><b>{selected.vehicle_reg_no||'—'}</b></div>
          </>}
          {type==='battery' && <>
            <div><span>Battery Make</span><b>{[...new Set(pickedBatteries.map(b=>b.battery_maker).filter(Boolean))].join(' / ')||'—'}</b></div>
            <div><span>Qty</span><b>{qtyNum}</b></div>
            <div><span>Battery No(s).</span><b>{pickedBatteries.map(b=>b.battery_no).join(', ')||'—'}</b></div>
          </>}
        </div>
      </div>}

      <div className="actions dealerCreateSaleActions">
        <button type="button" className="btn" onClick={onBack}>Cancel</button>
        <button type="button" className="btn primary"
          disabled={saving||loading||!selectedCustomer||!type||(type==='battery'?!batteryReady:!item)||Number(loanAmount||0)>Number(saleAmount||0)}
          onClick={save}>
          {saving?'Saving…':'Save & Send for Approval'}
        </button>
      </div>
    </div>
  </div>;
}

function DealerAllExpenses({dealer}){
  const [rows,setRows]=useState([]),[error,setError]=useState(''),[loading,setLoading]=useState(true),[search,setSearch]=useState(''),[cat,setCat]=useState(''),[openRows,setOpenRows]=useState({});
  const [editing,setEditing]=useState(null),[saving,setSaving]=useState(false),[verifiedToday,setVerifiedToday]=useState(false);
  const today=()=>new Date().toISOString().slice(0,10);
  const load=async()=>{
    setLoading(true);setError('');
    try{
      const r=await get('/dealer/cash-book/all-expenses',{noClientCache:true});
      setRows(r.expenses||r.rows||[]);
      setVerifiedToday(Boolean(r.verified_today));
    }catch(e){setError(e.message||'Could not load expenses')}
    finally{setLoading(false)}
  };
  useEffect(()=>{load()},[dealer?.id]);
  const label=r=>r.category_label||r.category||'Other';
  const cats=[...new Set(rows.map(label))].sort();
  const q=search.trim().toLowerCase();
  const filtered=rows.filter(r=>(!cat||label(r)===cat)&&[r.date,r.expense_no,label(r),r.paid_to,r.remarks,r.customer_name,r.customer_page_no].join(' ').toLowerCase().includes(q));
  const total=filtered.reduce((t,r)=>t+Number(r.amount||0),0);
  const byCat=Object.entries(filtered.reduce((m,r)=>{m[label(r)]=(m[label(r)]||0)+Number(r.amount||0);return m},{})).sort((a,b)=>b[1]-a[1]);
  const inr=n=>'₹ '+Number(n||0).toLocaleString('en-IN');
  const canEdit=(r)=>String(r.date||'').slice(0,10)===today()&&!verifiedToday;
  const openEdit=(r)=>{setError('');if(!canEdit(r)){setError('Aaj ka Cashbook Admin verify hone ke baad expense edit nahi ho sakta.');return}setEditing({...r})};
  const saveEdit=async()=>{
    if(!editing)return;
    if(!canEdit(editing)){setError('Cashbook verify ho chuka hai ya expense aaj ka nahi hai. Edit allowed nahi hai.');return}
    const amount=Number(editing.amount);
    if(!Number.isFinite(amount)||amount<=0){setError('Valid expense amount enter karein.');return}
    setSaving(true);setError('');
    try{
      await put('/dealer/cash-book/expenses/'+editing.id,{category:editing.category||'other',category_label:editing.category_label||editing.category||'Other',amount,paid_to:editing.paid_to||'',remarks:editing.remarks||'',folio:editing.folio||''});
      setEditing(null);await load();
    }catch(e){setError(e.message||'Could not update expense')}
    finally{setSaving(false)}
  };
  return <div className="dealerPage"><div className="dealerPanel"><div className="dealerPanelHead mxHead"><div><h3>All Expenses</h3><p>Shop expenses — category wise</p></div><div className="mxTools" style={{display:'flex',gap:8,flexWrap:'wrap'}}><select className="input" value={cat} onChange={e=>setCat(e.target.value)}><option value="">All Categories</option>{cats.map(c=><option key={c} value={c}>{c}</option>)}</select><input className="input dealerSearch" placeholder="Search expense no, customer, page no, remarks…" value={search} onChange={e=>setSearch(e.target.value)}/><button type="button" className="btn" onClick={load}>↻ Refresh</button></div></div>
    {error&&<div className="error">{error}</div>}
    {!loading&&<div className="card" style={{marginBottom:12,padding:10,background:verifiedToday?'#fef2f2':'#f0fdf4'}}>{verifiedToday?<><b>🔒 Aaj ka Cashbook Admin verified hai.</b> Ab kisi expense me change nahi ho sakta.</>:<><b>✎ Aaj ke expenses editable hain.</b> Admin verification ke baad edit automatically lock ho jayega.</>}</div>}
    {!loading&&!!byCat.length&&<div className="grid" style={{margin:'12px 0'}}><div className="card" style={{padding:10}}><small className="muted">Total{cat?' — '+cat:''}</small><b>{inr(total)}</b></div>{!cat&&byCat.map(([c,v])=><div className="card" key={c} style={{padding:10,cursor:'pointer'}} onClick={()=>setCat(c)}><small className="muted">{c}</small><b>{inr(v)}</b></div>)}</div>}
    {loading?<div className="dealerEmpty">Loading…</div>:<div className="tablewrap dealerTable mxTable"><table className="table"><thead><tr><th>Date</th><th>Expense No.</th><th>Category</th><th>Customer</th><th>Paid To</th><th>Remarks</th><th>Amount</th><th>Action</th></tr></thead><tbody>
      {filtered.map(r=><tr key={r.id} className={'mxRow two'+(openRows[r.id]?' open':'')} onClick={()=>setOpenRows(m=>({...m,[r.id]:!m[r.id]}))}><td className="mxK k4" data-label="Date">{formatDate(r.date)}<span className="mxChev">▾</span></td><td className="mxK k3" data-label="Expense No."><b>{r.expense_no||'—'}</b></td><td className="mxK k1" data-label="Category"><b>{label(r)}</b></td><td className="mxM" data-label="Customer">{r.customer_name?<><b>Pg {r.customer_page_no||'—'}</b> · {r.customer_name}</>:'—'}</td><td className="mxM" data-label="Paid To">{r.paid_to||'—'}</td><td className="mxM" data-label="Remarks">{r.remarks||'—'}</td><td className="mxK k2" data-label="Amount"><b>{inr(r.amount)}</b></td><td className="mxM mxAct" data-label="Action" onClick={e=>e.stopPropagation()}>{canEdit(r)?<button type="button" className="btn" onClick={()=>openEdit(r)}>Edit</button>:<span className="muted">🔒 Locked</span>}</td></tr>)}{!filtered.length&&<tr><td colSpan="8" className="muted">No expenses found.</td></tr>}</tbody><tfoot><tr><th colSpan="7">Total</th><th>{inr(total)}</th></tr></tfoot></table></div>}
    {editing&&<div className="modal" style={{zIndex:10000}} onMouseDown={e=>{if(e.target===e.currentTarget&&!saving)setEditing(null)}}><div className="modalbox" style={{maxWidth:560}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10}}><div><h3 style={{margin:0}}>Edit Expense</h3><p className="muted" style={{margin:'4px 0 0'}}>{editing.expense_no} · {formatDate(editing.date)}</p></div><button type="button" className="btn" onClick={()=>setEditing(null)}>✕</button></div>
      <div className="grid" style={{marginTop:14}}>
        <select className="input" value={editing.category||'other'} onChange={e=>setEditing({...editing,category:e.target.value,category_label:(DEALER_EXPENSE_CATEGORIES.find(x=>x[0]===e.target.value)||[])[1]||e.target.value})}>{DEALER_EXPENSE_CATEGORIES.map(x=><option key={x[0]} value={x[0]}>{x[1]}</option>)}</select>
        <input className="input" type="number" min="0.01" step="0.01" placeholder="Amount" value={editing.amount??''} onChange={e=>setEditing({...editing,amount:e.target.value})}/>
        <input className="input" placeholder="Paid To" value={editing.paid_to||''} onChange={e=>setEditing({...editing,paid_to:e.target.value})}/>
        <input className="input" placeholder="Remarks" value={editing.remarks||''} onChange={e=>setEditing({...editing,remarks:e.target.value})}/>
      </div>
      <div className="muted" style={{marginTop:10}}>Date change nahi ki ja sakti. Sirf aaj ke, Admin verification se pehle ke expenses edit honge.</div>
      <div className="actions" style={{marginTop:16}}><button type="button" className="btn" disabled={saving} onClick={()=>setEditing(null)}>Cancel</button><button type="button" className="btn primary" disabled={saving} onClick={saveEdit}>{saving?'Saving…':'Save Changes'}</button></div>
    </div></div>}
  </div></div>
}

function DealerIncentiveRegister({dealer}){
  const [data,setData]=useState({rows:[],summary:{}}),[error,setError]=useState(''),[loading,setLoading]=useState(true),[status,setStatus]=useState('all'),[search,setSearch]=useState('');
  const load=async()=>{setLoading(true);try{const r=await get('/dealer/incentive-record');setData(r)}catch(e){setError(e.message||'Could not load incentive record')}finally{setLoading(false)}};
  useEffect(()=>{load()},[]);
  const q=search.trim().toLowerCase();
  const rows=(data.rows||[]).filter(r=>status==='all'||r.status.toLowerCase().replace(' ','_')===status).filter(r=>[r.date,r.bill_no,r.model,r.chassis_no,r.customer,r.mobile_no,r.vehicle_no,r.voucher_no,r.status].join(' ').toLowerCase().includes(q));
  const s=data.summary||{};
  return <div className="dealerPage"><div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>Incentive Record</h3><p>Paid / Pending / Not Recorded incentive status</p></div><input className="input dealerSearch" placeholder="Search bill, customer, chassis…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
    <div className="actions" style={{marginBottom:12,flexWrap:'wrap'}}>
      <button className={'btn '+(status==='all'?'primary':'')} onClick={()=>setStatus('all')}>All {s.total||0}</button>
      <button className={'btn '+(status==='paid'?'primary':'')} onClick={()=>setStatus('paid')}>Paid {s.paid||0}</button>
      <button className={'btn '+(status==='pending_payment'?'primary':'')} onClick={()=>setStatus('pending_payment')}>Pending {s.pending||0}</button>
      <button className={'btn '+(status==='not_recorded'?'primary':'')} onClick={()=>setStatus('not_recorded')}>Not Recorded {s.not_recorded||0}</button>
    </div>
    {error&&<div className="error">{error}</div>}
    {loading?<div className="dealerEmpty">Loading…</div>:<div className="tablewrap dealerTable"><table className="table"><thead><tr><th>Date</th><th>Bill No.</th><th>Customer</th><th>Chassis</th><th>Model</th><th>Incentive</th><th>Voucher</th><th>Paid Date</th><th>Status</th></tr></thead><tbody>
      {rows.map(r=><tr key={r.vehicle_id}><td>{formatDate(r.date)}</td><td><b>{r.bill_no||'—'}</b></td><td>{r.customer||'—'}<br/><span className="muted">{r.mobile_no||''}</span></td><td>{r.chassis_no||'—'}</td><td>{r.model||'—'}</td><td>₹ {Number(r.incentive_amount||0).toLocaleString('en-IN')}</td><td>{r.voucher_no||'—'}</td><td>{r.paid_date?formatDate(r.paid_date):'—'}</td><td><b>{r.status}</b></td></tr>)}
      {!rows.length&&<tr><td colSpan="9" className="muted">No incentive records found.</td></tr>}
    </tbody></table></div>}
  </div></div>
}
function DealerAllSale({tab,dealer,invoices,challans,canCashBook,canOldRickshawSales}) {
  // All Sale (upar red strip): Tax Invoice, Old Rickshaw Sale, Battery Sale, Delivery Challan, Incentive Record.
  return <div className="dealerPage">
    {tab==='invoices'&&<DealerSaleInvoices invoices={invoices} canPrint={!['showroom','branch'].includes(String(dealer?.dealer_category||'dealer').toLowerCase())}/>}
    {tab==='old-rickshaw-sales'&&canOldRickshawSales&&<DealerOldRickshawSold/>}
    {tab==='battery-sales'&&<DealerBatterySales/>}
    {tab==='challans'&&<DealerSaleChallans challans={challans}/>}
    {tab==='incentive'&&canCashBook&&<DealerIncentiveRegister dealer={dealer}/>}
  </div>;
}
function DealerSaleInvoices({invoices,canPrint=true}) {
  const [search,setSearch]=useState('');
  const [printId,setPrintId]=useState(null);
  const q=search.trim().toLowerCase();
  const rows=(invoices||[]).filter(v=>!q||[v.date,v.bill_no,v.chassis_no,v.product_name,v.buyer_name].join(' ').toLowerCase().includes(q));
  return <div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>Tax Invoices</h3><p>New Rickshaw ke bane hue tax invoice.</p></div><input className="input dealerSearch" placeholder="Search bill, chassis, buyer…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
    <DealerTable headers={canPrint?['Date','Bill No.','Chassis No.','Model','Buyer','Total','Print']:['Date','Bill No.','Chassis No.','Model','Buyer','Total']} rows={rows} pageSize={35} row={i=><><td data-label="Date">{formatDate(i.date)}</td><td data-label="Bill No.">{i.bill_no}</td><td data-label="Chassis No.">{i.chassis_no}</td><td data-label="Model">{i.product_name}</td><td data-label="Buyer">{i.buyer_name}</td><td data-label="Total">{i.bill_total}</td>{canPrint&&<td data-label="Print"><button type="button" className="btn" onClick={()=>setPrintId(i.id)}>🖨 Print</button></td>}</>}/>
    {canPrint&&printId&&<TaxInvoicePrintView invoiceId={printId} onClose={()=>setPrintId(null)}/>}
  </div>;
}
function DealerBatterySales() {
  const [rows,setRows]=useState([]);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [search,setSearch]=useState('');
  const load=async()=>{
    try{setError('');const r=await get('/dealer/battery-sales',{noClientCache:true});setRows(r.sales||[]);}
    catch(e){setError(e.message||'Could not load battery sales.')}
    finally{setLoading(false)}
  };
  useEffect(()=>{load()},[]);
  const q=search.trim().toLowerCase();
  const list=rows.filter(v=>!q||[v.customer_name,v.description,v.page_no].join(' ').toLowerCase().includes(q));
  const money=(n)=>'₹ '+Number(n||0).toLocaleString('en-IN');
  const statusLabel=(s)=>s==='PENDING'?'PENDING':s==='APPROVED'?'APPROVED':'SOLD';
  return <div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>Battery Sale</h3><p>Aapke dwara ki gayi battery sales.</p></div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}><input className="input dealerSearch" placeholder="Search customer…" value={search} onChange={e=>setSearch(e.target.value)}/><button type="button" className="btn" onClick={load}>↻ Refresh</button></div></div>
    {error&&<ErrorBanner message={error}/>}
    {loading?<div className="dealerEmpty">Loading…</div>:!list.length?<div className="dealerEmpty">Koi Battery Sale nahi mili.</div>:
    <div className="tablewrap dealerTable"><table className="table">
      <thead><tr><th>Date</th><th>Customer</th><th>Details</th><th>Sale Amt.</th><th>Received</th><th>Status</th></tr></thead>
      <tbody>{list.map(v=><tr key={v.id}>
        <td data-label="Date">{formatDate(v.date)}</td><td data-label="Customer"><b>{v.customer_name||'—'}</b></td><td data-label="Details">{v.description||'—'}</td>
        <td data-label="Sale Amt.">{money(v.sale_amount)}</td><td data-label="Received">{money(v.amount_received)}</td><td data-label="Status"><span className={'dealerOldStockStatus '+(v.status==='PENDING'?'available':'sold')}>{statusLabel(v.status)}</span></td>
      </tr>)}</tbody>
    </table></div>}
  </div>;
}

function DealerSaleChallans({challans}) {
  const [search,setSearch]=useState('');
  const q=search.trim().toLowerCase();
  const rows=(challans||[]).filter(v=>!q||[v.date,v.challan_no,v.chassis_no,v.product_name,v.destination].join(' ').toLowerCase().includes(q));
  return <div className="dealerPanel">
    <div className="dealerPanelHead"><div><h3>Delivery Challans</h3><p>Aapko mile hue delivery challan.</p></div><input className="input dealerSearch" placeholder="Search challan, chassis, model…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
    <DealerTable headers={['Date','Challan No.','Chassis No.','Model','Destination']} rows={rows} pageSize={35} row={c=><><td data-label="Date">{formatDate(c.date)}</td><td data-label="Challan No.">{c.challan_no}</td><td data-label="Chassis No.">{c.chassis_no}</td><td data-label="Model">{c.product_name}</td><td data-label="Destination">{c.destination}</td></>}/>
  </div>;
}
